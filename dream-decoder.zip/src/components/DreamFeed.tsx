import React, { useState } from 'react';
import { Search, Filter, Sparkles, Moon, X, Flame, Trophy, Plus } from 'lucide-react';
import { Dream } from '../types.ts';
import { DreamCard } from './DreamCard.tsx';

interface DreamFeedProps {
  dreams: Dream[];
  onSelectDream: (dream: Dream) => void;
  activeSymbolFilter: string | null;
  onClearSymbolFilter: () => void;
  onFilterSymbol: (symbol: string) => void;
  onOpenSubmitDream: () => void;
}

export const DreamFeed: React.FC<DreamFeedProps> = ({
  dreams,
  onSelectDream,
  activeSymbolFilter,
  onClearSymbolFilter,
  onFilterSymbol,
  onOpenSubmitDream,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<
    'all' | 'needs-decoders' | 'crowned' | 'lucid' | 'nightmares' | 'mystical'
  >('all');

  const filteredDreams = dreams.filter((dream) => {
    // Symbol filter
    if (activeSymbolFilter) {
      const hasSym = dream.recurringSymbols.some(
        (s) => s.toLowerCase() === activeSymbolFilter.toLowerCase()
      );
      if (!hasSym) return false;
    }

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const inTitle = dream.title.toLowerCase().includes(q);
      const inStory = dream.story.toLowerCase().includes(q);
      const inAuthor = dream.authorName.toLowerCase().includes(q);
      const inSymbols = dream.recurringSymbols.some((s) => s.toLowerCase().includes(q));
      if (!inTitle && !inStory && !inAuthor && !inSymbols) return false;
    }

    // Category filter
    switch (filterType) {
      case 'needs-decoders':
        return dream.interpretations.length <= 1;
      case 'crowned':
        return !!dream.crownedInterpretationId;
      case 'lucid':
        return dream.lucidityLevel >= 4;
      case 'nightmares':
        return dream.mood === 'Nightmarish' || dream.mood === 'Anxious';
      case 'mystical':
        return dream.mood === 'Mystical' || dream.mood === 'Ethereal' || dream.mood === 'Surreal';
      default:
        return true;
    }
  });

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Hero Welcome Banner */}
      <div className="relative rounded-2xl bg-gradient-to-r from-[#12132a] via-[#0e1022] to-[#161226] border border-white/[0.08] p-6 sm:p-8 mb-8 overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-950/80 border border-indigo-500/30 text-indigo-300 text-xs font-medium mb-3">
            <Moon className="w-3.5 h-3.5 text-indigo-400" />
            The Collective Unconscious Feed
          </div>
          <h1 className="font-display font-bold text-2xl sm:text-3xl text-slate-100 mb-2 leading-tight">
            Decode Dreams. Unveil Symbols. Earn Resonance Points.
          </h1>
          <p className="text-xs sm:text-sm text-slate-300/90 leading-relaxed mb-5">
            Step into the nocturnal logs of fellow dreamers. Provide Jungian and psychological decodes. 
            The most resonant interpretations win points, badges, and the title of Grand Oracle.
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={onOpenSubmitDream}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm shadow-indigo-600/30 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <Plus className="w-4 h-4" />
              <span>Log Your Dream (+5 pts)</span>
            </button>
            <span className="text-xs text-slate-400">
              Or pick an open dream below to decode for <span className="text-indigo-300 font-mono font-medium">+15 pts</span>!
            </span>
          </div>
        </div>

        {/* Ambient background glow orb */}
        <div className="absolute right-0 top-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
      </div>

      {/* Search and Filters */}
      <div className="space-y-4 mb-8">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          {/* Search bar */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search dreams by story, symbols, or dreamer name..."
              className="w-full pl-10 pr-4 py-2 text-xs sm:text-sm rounded-xl bg-[#0e101f] border border-white/[0.08] text-slate-200 placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          {/* Active symbol tag filter */}
          {activeSymbolFilter && (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-indigo-950/70 border border-indigo-500/40 text-xs text-indigo-200">
              <span>Motif: <strong>#{activeSymbolFilter}</strong></span>
              <button
                onClick={onClearSymbolFilter}
                className="hover:text-white p-0.5"
                title="Clear motif filter"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        {/* Filter Segmented Control Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto p-1 bg-white/[0.02] rounded-xl border border-white/[0.06] text-xs">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
              filterType === 'all'
                ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Dreams ({dreams.length})
          </button>

          <button
            onClick={() => setFilterType('needs-decoders')}
            className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
              filterType === 'needs-decoders'
                ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Needs Decoders (High Reward)
          </button>

          <button
            onClick={() => setFilterType('crowned')}
            className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
              filterType === 'crowned'
                ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            👑 Crowned Epiphanies
          </button>

          <button
            onClick={() => setFilterType('lucid')}
            className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
              filterType === 'lucid'
                ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Lucid Dreams (IV–V)
          </button>

          <button
            onClick={() => setFilterType('mystical')}
            className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
              filterType === 'mystical'
                ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Mystical & Surreal
          </button>

          <button
            onClick={() => setFilterType('nightmares')}
            className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
              filterType === 'nightmares'
                ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Nightmares & Shadows
          </button>
        </div>
      </div>

      {/* Dreams Grid */}
      {filteredDreams.length === 0 ? (
        <div className="text-center py-16 bg-[#0e101f] border border-white/[0.06] rounded-2xl p-8">
          <Moon className="w-10 h-10 text-indigo-400/40 mx-auto mb-3" />
          <h3 className="font-display font-semibold text-lg text-slate-200 mb-1">
            No dreams found matching criteria
          </h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto mb-5">
            Try adjusting your search query, clearing motif filters, or be the first to record a dream in this category!
          </p>
          <button
            onClick={onOpenSubmitDream}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            Log a New Dream
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filteredDreams.map((dream) => (
            <DreamCard
              key={dream.id}
              dream={dream}
              onSelect={onSelectDream}
              onFilterSymbol={onFilterSymbol}
            />
          ))}
        </div>
      )}
    </div>
  );
};

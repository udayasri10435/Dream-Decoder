import React, { useState } from 'react';
import { BookOpen, Search, Filter, Sparkles, ArrowRight } from 'lucide-react';
import { DREAM_SYMBOLS } from '../data/symbols.ts';
import { DreamSymbolItem } from '../types.ts';

interface SymbolLexiconViewProps {
  onSelectSymbolForFeed: (symbolKeyword: string) => void;
}

export const SymbolLexiconView: React.FC<SymbolLexiconViewProps> = ({ onSelectSymbolForFeed }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = [
    'All',
    'Nature & Elements',
    'Structures & Spaces',
    'Creatures & Beasts',
    'Motions & States',
    'Objects & Relics'
  ];

  const filteredSymbols = DREAM_SYMBOLS.filter((item) => {
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesSearch = 
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.archetype.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.meaning.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.keywords.some(k => k.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-950/60 border border-indigo-500/30 text-indigo-300 text-xs font-medium mb-3">
          <BookOpen className="w-3.5 h-3.5" />
          The Oneiric Codex
        </div>
        <h1 className="font-display font-bold text-3xl sm:text-4xl text-slate-100 mb-3">
          Dream Symbol Lexicon
        </h1>
        <p className="text-sm text-slate-300/90 leading-relaxed">
          Explore the recurring archetypes and universal subconscious metaphors that surface in dreams.
          Use these insights to formulate resonant interpretations for fellow community members.
        </p>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3 mb-8">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search symbols by motif, archetype, or keyword (e.g. water, mirror, falling)..."
            className="w-full pl-10 pr-4 py-2 text-xs sm:text-sm rounded-xl bg-[#0e101f] border border-white/[0.08] text-slate-200 placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition-colors"
          />
        </div>

        {/* Categories as clean interactive button controls */}
        <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto p-1 bg-white/[0.03] rounded-lg border border-white/[0.06] text-xs">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/40 shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Symbols */}
      {filteredSymbols.length === 0 ? (
        <div className="text-center py-16 bg-[#0e101f] border border-white/[0.06] rounded-2xl">
          <Sparkles className="w-8 h-8 text-indigo-400/50 mx-auto mb-3" />
          <p className="text-sm font-medium text-slate-200 mb-1">No symbols found</p>
          <p className="text-xs text-slate-400">Try adjusting your search terms or selecting another category.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredSymbols.map((item) => (
            <div
              key={item.id}
              className="bg-[#0e101f] border border-white/[0.07] hover:border-indigo-500/35 rounded-xl p-5 sm:p-6 transition-all duration-200 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between text-[11px] text-slate-400 mb-2">
                  <span className="font-mono text-indigo-300/80">{item.category}</span>
                  <span className="text-slate-400">Jungian Codex</span>
                </div>

                <h3 className="font-display font-semibold text-lg text-slate-100 mb-1">
                  {item.name}
                </h3>

                <p className="text-xs font-medium text-indigo-300 mb-3">
                  Archetype: <span className="text-slate-200 font-normal">{item.archetype}</span>
                </p>

                <p className="text-xs text-slate-300/90 leading-relaxed mb-4">
                  {item.meaning}
                </p>

                <div className="p-3 rounded-lg bg-indigo-950/20 border border-indigo-500/20 text-xs text-indigo-200/90 italic mb-4">
                  "{item.jungianNote}"
                </div>
              </div>

              <div className="pt-3 border-t border-white/[0.06] flex items-center justify-between">
                <div className="flex flex-wrap gap-1 text-[11px] text-slate-400">
                  {item.keywords.slice(0, 3).map((k) => (
                    <span key={k} className="text-slate-400">#{k}</span>
                  ))}
                </div>

                <button
                  onClick={() => onSelectSymbolForFeed(item.keywords[0])}
                  className="flex items-center gap-1 text-xs font-medium text-indigo-400 hover:text-indigo-300 transition-colors"
                >
                  <span>Find Dreams</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

import React from 'react';
import { Trophy, Crown, Sparkles, Award, Star, ArrowUpRight, CheckCircle2, Shield } from 'lucide-react';
import { UserProfile } from '../types.ts';

interface LeaderboardViewProps {
  users: UserProfile[];
  currentUser: UserProfile;
  onSelectUser: (user: UserProfile) => void;
  onOpenSubmitDream: () => void;
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({
  users,
  currentUser,
  onSelectUser,
  onOpenSubmitDream,
}) => {
  // Sort users by points descending
  const sortedUsers = [...users].sort((a, b) => b.points - a.points);

  const getNextRankThreshold = (pts: number) => {
    if (pts < 50) return { nextRank: 'Lucid Wanderer', nextPts: 50, currentPts: pts };
    if (pts < 200) return { nextRank: 'Archetype Weaver', nextPts: 200, currentPts: pts };
    if (pts < 500) return { nextRank: 'Depth Psychologist', nextPts: 500, currentPts: pts };
    if (pts < 1000) return { nextRank: 'Grand Oracle', nextPts: 1000, currentPts: pts };
    return { nextRank: 'Ascended Oracle', nextPts: pts, currentPts: pts };
  };

  const currentRankInfo = getNextRankThreshold(currentUser.points);
  const progressPercent = Math.min(100, Math.round((currentUser.points / currentRankInfo.nextPts) * 100));

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      {/* Page Title */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-950/60 border border-indigo-500/30 text-indigo-300 text-xs font-medium mb-3">
          <Trophy className="w-3.5 h-3.5 text-amber-400" />
          The Oneiric Guild & Master Decoders
        </div>
        <h1 className="font-display font-bold text-3xl sm:text-4xl text-slate-100 mb-3">
          Decoder Leaderboard
        </h1>
        <p className="text-sm text-slate-300/90 leading-relaxed">
          The community decodes dreams through archetypal, psychological, and mythic lenses.
          The most resonated interpretations win points, badges, and the title of Grand Oracle.
        </p>
      </div>

      {/* Point Rules & Economy Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3.5 mb-10">
        <div className="p-4 rounded-xl bg-[#0f1122] border border-white/[0.08]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-300">Log a Dream</span>
            <span className="text-xs font-mono font-bold text-indigo-400 tabular-nums">+5 pts</span>
          </div>
          <p className="text-[11px] text-slate-400 leading-normal">
            Contribute a personal dream to the collective dream journal for analysis.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-[#0f1122] border border-white/[0.08]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-300">Offer Decode</span>
            <span className="text-xs font-mono font-bold text-indigo-400 tabular-nums">+15 pts</span>
          </div>
          <p className="text-[11px] text-slate-400 leading-normal">
            Submit a thoughtful interpretation breaking down subconscious symbols.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-[#0f1122] border border-white/[0.08]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-300">Community Like</span>
            <span className="text-xs font-mono font-bold text-rose-400 tabular-nums">+10 pts</span>
          </div>
          <p className="text-[11px] text-slate-400 leading-normal">
            Every fellow dreamer who resonates with your decode grants you points.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-[#0f1122] border border-amber-500/30 bg-amber-950/10">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-amber-300 flex items-center gap-1">
              <Crown className="w-3.5 h-3.5 text-amber-400" />
              Epiphany Crown
            </span>
            <span className="text-xs font-mono font-bold text-amber-400 tabular-nums">+50 pts</span>
          </div>
          <p className="text-[11px] text-slate-400 leading-normal">
            The original dreamer crowns your decode as their most profound breakthrough.
          </p>
        </div>
      </div>

      {/* Active User Rank Status Card */}
      <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-r from-indigo-950/40 via-[#101226] to-purple-950/30 border border-indigo-500/30 mb-8 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4 w-full sm:w-auto">
          <img
            src={currentUser.avatar}
            alt={currentUser.name}
            className="w-14 h-14 rounded-full object-cover ring-2 ring-indigo-400/40"
          />
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-display font-semibold text-lg text-slate-100">
                {currentUser.name}
              </h2>
              <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-900/60 border border-indigo-400/40 text-indigo-200 font-medium">
                {currentUser.rankName}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">{currentUser.title}</p>
            <div className="flex items-center gap-3 text-xs text-slate-300 mt-2">
              <span><strong className="font-mono text-indigo-300 tabular-nums">{currentUser.points}</strong> Points</span>
              <span aria-hidden="true">·</span>
              <span><strong className="font-mono text-slate-200 tabular-nums">{currentUser.interpretationsCount}</strong> Decodes</span>
              <span aria-hidden="true">·</span>
              <span className="text-amber-300"><strong className="font-mono tabular-nums">{currentUser.winsCount}</strong> Crowned Wins</span>
            </div>
          </div>
        </div>

        {/* Rank progress */}
        <div className="w-full sm:w-64">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
            <span>Next Rank: <strong className="text-slate-200">{currentRankInfo.nextRank}</strong></span>
            <span className="font-mono tabular-nums text-indigo-300">{currentUser.points} / {currentRankInfo.nextPts} pts</span>
          </div>
          <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-500" 
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Guild Leaderboard Table */}
      <div className="bg-[#0e101f] border border-white/[0.08] rounded-2xl overflow-hidden shadow-xl">
        <div className="p-4 sm:p-5 border-b border-white/[0.06] flex items-center justify-between">
          <h3 className="font-display font-semibold text-base text-slate-100 flex items-center gap-2">
            <Award className="w-4 h-4 text-indigo-400" />
            Master Decoders of the Realm
          </h3>
          <span className="text-xs text-slate-400">
            Updated in real-time with each resonance
          </span>
        </div>

        <div className="divide-y divide-white/[0.06]">
          {sortedUsers.map((user, idx) => {
            const isCurrentUser = user.id === currentUser.id;
            return (
              <div
                key={user.id}
                className={`p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-colors ${
                  isCurrentUser ? 'bg-indigo-950/30' : 'hover:bg-white/[0.02]'
                }`}
              >
                {/* Left: Position & Avatar & Info */}
                <div className="flex items-center gap-4 min-w-0">
                  {/* Position number */}
                  <div className="w-7 text-center font-mono font-bold text-sm shrink-0">
                    {idx === 0 ? (
                      <span className="text-amber-400 text-lg">👑 1</span>
                    ) : idx === 1 ? (
                      <span className="text-slate-300 text-base">2</span>
                    ) : idx === 2 ? (
                      <span className="text-amber-600 text-base">3</span>
                    ) : (
                      <span className="text-slate-400">{idx + 1}</span>
                    )}
                  </div>

                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-10 h-10 rounded-full object-cover ring-1 ring-white/10 shrink-0"
                  />

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-100 text-sm truncate">
                        {user.name}
                      </span>
                      {isCurrentUser && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-900/60 text-indigo-200 font-mono">
                          You
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <span className="text-indigo-300 font-medium">{user.rankName}</span>
                      <span aria-hidden="true">·</span>
                      <span className="truncate">{user.title}</span>
                    </div>
                  </div>
                </div>

                {/* Right: Scores & Switch persona button */}
                <div className="flex items-center justify-between sm:justify-end gap-6 shrink-0 text-xs">
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Decodes</span>
                    <span className="font-mono text-slate-200 tabular-nums font-medium">
                      {user.interpretationsCount}
                    </span>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Crowned Wins</span>
                    <span className="font-mono text-amber-300 tabular-nums font-semibold flex items-center justify-end gap-1">
                      <Crown className="w-3 h-3 text-amber-400" />
                      {user.winsCount}
                    </span>
                  </div>

                  <div className="text-right min-w-[70px]">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Total Points</span>
                    <span className="font-mono text-indigo-300 text-sm font-bold tabular-nums">
                      {user.points} pts
                    </span>
                  </div>

                  {!isCurrentUser ? (
                    <button
                      onClick={() => onSelectUser(user)}
                      className="px-2.5 py-1 text-xs rounded-md bg-white/[0.04] hover:bg-white/[0.08] text-slate-300 border border-white/[0.08] transition-colors"
                      title="Act as this user to test voting or submitting"
                    >
                      Act as User
                    </button>
                  ) : (
                    <div className="px-2.5 py-1 text-xs text-indigo-400 flex items-center gap-1 font-medium">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Active
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

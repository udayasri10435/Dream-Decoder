import React from 'react';
import { MessageSquare, Heart, Crown, Sparkles, Compass, Eye } from 'lucide-react';
import { Dream } from '../types.ts';

interface DreamCardProps {
  dream: Dream;
  onSelect: (dream: Dream) => void;
  onFilterSymbol?: (symbol: string) => void;
}

export const DreamCard: React.FC<DreamCardProps> = ({ dream, onSelect, onFilterSymbol }) => {
  // Find top interpretation
  const topInterp = dream.interpretations.length > 0
    ? [...dream.interpretations].sort((a, b) => b.upvotes - a.upvotes)[0]
    : null;

  const totalVotes = dream.interpretations.reduce((sum, i) => sum + i.upvotes, 0);

  // Formatting date
  const timeFormatted = new Date(dream.createdAt).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric'
  });

  return (
    <article 
      onClick={() => onSelect(dream)}
      className="group relative bg-[#0f111f]/70 hover:bg-[#121424] border border-white/[0.07] hover:border-indigo-500/35 rounded-xl p-5 sm:p-6 transition-all duration-200 cursor-pointer flex flex-col justify-between"
    >
      <div>
        {/* Anti-Slop Unboxed Metadata Header */}
        <div className="flex flex-wrap items-center justify-between gap-y-1 gap-x-2 text-xs text-slate-400 mb-3">
          <div className="flex items-center gap-2">
            <img
              src={dream.authorAvatar}
              alt={dream.authorName}
              className="w-5 h-5 rounded-full object-cover ring-1 ring-white/10"
            />
            <span className="font-medium text-slate-200">{dream.authorName}</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>{timeFormatted}</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="text-indigo-300/90">{dream.mood}</span>
          </div>

          <div className="flex items-center gap-2 text-[11px] text-slate-400">
            <span>{dream.sleepStage}</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="font-mono tabular-nums text-slate-300">
              Lucidity {dream.lucidityLevel}/5
            </span>
          </div>
        </div>

        {/* Title */}
        <h2 className="font-display font-semibold text-lg sm:text-xl text-slate-100 group-hover:text-indigo-200 transition-colors mb-2.5 leading-snug">
          {dream.title}
        </h2>

        {/* Story Snippet */}
        <p className="text-sm text-slate-300/90 line-clamp-3 leading-relaxed mb-4">
          {dream.story}
        </p>

        {/* Recurring Symbols as quiet unboxed text */}
        {dream.recurringSymbols.length > 0 && (
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-400 mb-4">
            <span className="text-slate-400 text-[11px]">Motifs:</span>
            {dream.recurringSymbols.map((sym, idx) => (
              <React.Fragment key={sym}>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (onFilterSymbol) onFilterSymbol(sym);
                  }}
                  className="text-indigo-300/80 hover:text-indigo-200 underline decoration-indigo-500/30 hover:decoration-indigo-300 transition-colors"
                >
                  #{sym}
                </button>
                {idx < dream.recurringSymbols.length - 1 && (
                  <span aria-hidden="true" className="text-slate-700">·</span>
                )}
              </React.Fragment>
            ))}
          </div>
        )}

        {/* Top-Voted Interpretation / Winning Epiphany Callout */}
        {topInterp && (
          <div className={`mt-3 p-3 rounded-lg border text-xs ${
            dream.crownedInterpretationId === topInterp.id
              ? 'bg-amber-950/20 border-amber-500/30'
              : 'bg-white/[0.02] border-white/[0.06]'
          }`}>
            <div className="flex items-center justify-between text-[11px] mb-1.5">
              <span className="flex items-center gap-1.5 font-medium text-slate-300">
                {dream.crownedInterpretationId === topInterp.id ? (
                  <>
                    <Crown className="w-3.5 h-3.5 text-amber-400" />
                    <span className="text-amber-300 font-semibold">Crowned Epiphany</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Top Resonant Decode</span>
                  </>
                )}
                <span className="text-slate-400 font-normal">by {topInterp.authorName}</span>
              </span>
              <span className="font-mono text-indigo-300 tabular-nums font-semibold">
                +{topInterp.pointsAwarded} pts
              </span>
            </div>
            <p className="text-slate-300 italic line-clamp-2 pl-2 border-l-2 border-indigo-400/40">
              "{topInterp.content}"
            </p>
          </div>
        )}
      </div>

      {/* Card Footer: Metrics & Action */}
      <div className="flex items-center justify-between pt-4 mt-4 border-t border-white/[0.06] text-xs text-slate-400">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <MessageSquare className="w-3.5 h-3.5 text-indigo-400" />
            <span className="font-mono tabular-nums text-slate-300">{dream.interpretations.length}</span>
            <span>{dream.interpretations.length === 1 ? 'decode' : 'decodes'}</span>
          </span>

          <span className="flex items-center gap-1.5">
            <Heart className="w-3.5 h-3.5 text-rose-400/80" />
            <span className="font-mono tabular-nums text-slate-300">{totalVotes}</span>
            <span>resonances</span>
          </span>

          {dream.oracleAnalysis && (
            <span className="hidden sm:flex items-center gap-1 text-[11px] text-purple-300/80">
              <Compass className="w-3 h-3 text-purple-400" />
              Oracle Decoded
            </span>
          )}
        </div>

        <span className="text-indigo-400 group-hover:text-indigo-300 flex items-center gap-1 font-medium transition-transform group-hover:translate-x-0.5">
          Decode Dream &rarr;
        </span>
      </div>
    </article>
  );
};

import React, { useState } from 'react';
import { X, Moon, Sparkles, Plus, Check } from 'lucide-react';
import { DreamMood, SleepStage, UserProfile } from '../types.ts';

interface SubmitDreamModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onSubmitDream: (dreamData: {
    title: string;
    story: string;
    mood: DreamMood;
    lucidityLevel: number;
    sleepStage: SleepStage;
    recurringSymbols: string[];
  }) => Promise<void>;
}

const COMMON_SYMBOLS = [
  'water', 'ocean', 'flying', 'falling', 'clocks', 'mirrors', 
  'teeth', 'labyrinth', 'train', 'forest', 'tower', 'beast', 
  'doors', 'fire', 'shadow', 'snake'
];

export const SubmitDreamModal: React.FC<SubmitDreamModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onSubmitDream,
}) => {
  const [title, setTitle] = useState('');
  const [story, setStory] = useState('');
  const [mood, setMood] = useState<DreamMood>('Surreal');
  const [lucidityLevel, setLucidityLevel] = useState<number>(3);
  const [sleepStage, setSleepStage] = useState<SleepStage>('Deep REM');
  const [selectedSymbols, setSelectedSymbols] = useState<string[]>([]);
  const [customSymbol, setCustomSymbol] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const toggleSymbol = (sym: string) => {
    if (selectedSymbols.includes(sym)) {
      setSelectedSymbols(selectedSymbols.filter(s => s !== sym));
    } else {
      setSelectedSymbols([...selectedSymbols, sym]);
    }
  };

  const handleAddCustomSymbol = () => {
    const clean = customSymbol.trim().toLowerCase().replace(/[^a-z0-9-]/g, '');
    if (clean && !selectedSymbols.includes(clean)) {
      setSelectedSymbols([...selectedSymbols, clean]);
      setCustomSymbol('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !story.trim()) return;

    try {
      setIsSubmitting(true);
      await onSubmitDream({
        title: title.trim(),
        story: story.trim(),
        mood,
        lucidityLevel,
        sleepStage,
        recurringSymbols: selectedSymbols,
      });
      onClose();
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getLucidityLabel = (lvl: number) => {
    switch (lvl) {
      case 1: return '1 - Somnolent (Foggy, involuntary)';
      case 2: return '2 - Passenger (Vivid but unquestioned)';
      case 3: return '3 - Semi-Aware (Flashes of strangeness noticed)';
      case 4: return '4 - Lucid Observer (Knew I was dreaming)';
      case 5: return '5 - Lucid Architect (Conscious agency & control)';
      default: return `${lvl}/5`;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs overflow-y-auto">
      <div className="bg-[#0e101f] border border-indigo-500/30 rounded-2xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl my-8 relative">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/[0.08] mb-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-950/80 border border-indigo-500/30 flex items-center justify-center text-indigo-300">
              <Moon className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-display font-semibold text-xl text-slate-100">
                Log a Nocturnal Vision
              </h2>
              <p className="text-xs text-slate-400">
                Posting a dream awards <span className="text-indigo-300 font-mono">+5 points</span> and invites the community to decode it.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-md"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Dream Title */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Dream Title
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. The Glass Tower in the Sunken Forest"
              className="w-full px-3.5 py-2 text-sm rounded-lg bg-white/[0.03] border border-white/[0.08] text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition-colors font-medium"
            />
          </div>

          {/* Dream Story / Log */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              The Dream Narrative (Record sensory impressions, atmosphere, dialogue, endings)
            </label>
            <textarea
              required
              rows={5}
              value={story}
              onChange={(e) => setStory(e.target.value)}
              placeholder="I found myself walking along a shoreline where the sand was ground amethyst. A distant bell chimed three times..."
              className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-lg bg-white/[0.03] border border-white/[0.08] text-slate-200 placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition-colors leading-relaxed font-serif"
            />
          </div>

          {/* Metadata Row: Mood & Sleep Stage */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Atmosphere / Emotional Tone
              </label>
              <select
                value={mood}
                onChange={(e) => setMood(e.target.value as DreamMood)}
                className="w-full px-3 py-2 text-xs rounded-lg bg-white/[0.03] border border-white/[0.08] text-slate-200 focus:outline-none focus:border-indigo-500"
              >
                <option value="Surreal" className="bg-[#121424]">Surreal (Bizarre & Non-linear)</option>
                <option value="Ethereal" className="bg-[#121424]">Ethereal (Luminous, Peaceful)</option>
                <option value="Mystical" className="bg-[#121424]">Mystical (Numinous, Sacred)</option>
                <option value="Lucid" className="bg-[#121424]">Lucid (High Clarity)</option>
                <option value="Anxious" className="bg-[#121424]">Anxious (Urgent, Chased)</option>
                <option value="Nightmarish" className="bg-[#121424]">Nightmarish (Visceral Dread)</option>
                <option value="Nostalgic" className="bg-[#121424]">Nostalgic (Past Memories)</option>
                <option value="Prophetic" className="bg-[#121424]">Prophetic (Fateful Omen)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Sleep Stage / Timing
              </label>
              <select
                value={sleepStage}
                onChange={(e) => setSleepStage(e.target.value as SleepStage)}
                className="w-full px-3 py-2 text-xs rounded-lg bg-white/[0.03] border border-white/[0.08] text-slate-200 focus:outline-none focus:border-indigo-500"
              >
                <option value="Deep REM" className="bg-[#121424]">Deep REM (Middle of the Night)</option>
                <option value="Morning Twilight" className="bg-[#121424]">Morning Twilight (Pre-Awakening)</option>
                <option value="Hypnagogic" className="bg-[#121424]">Hypnagogic (Falling Asleep)</option>
                <option value="False Awakening" className="bg-[#121424]">False Awakening (Woke up inside dream)</option>
              </select>
            </div>
          </div>

          {/* Lucidity Slider */}
          <div>
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="font-medium text-slate-300">Lucidity Level</span>
              <span className="text-indigo-300 font-medium">{getLucidityLabel(lucidityLevel)}</span>
            </div>
            <input
              type="range"
              min={1}
              max={5}
              value={lucidityLevel}
              onChange={(e) => setLucidityLevel(Number(e.target.value))}
              className="w-full accent-indigo-500 bg-white/10 rounded-lg cursor-pointer h-2"
            />
          </div>

          {/* Common Motifs & Symbols Tagging */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Select Recurring Motifs for Community Analyzers
            </label>
            <div className="flex flex-wrap gap-1.5 mb-2.5">
              {COMMON_SYMBOLS.map((sym) => {
                const isSelected = selectedSymbols.includes(sym);
                return (
                  <button
                    key={sym}
                    type="button"
                    onClick={() => toggleSymbol(sym)}
                    className={`px-2.5 py-1 text-xs rounded-md border transition-colors flex items-center gap-1 ${
                      isSelected
                        ? 'bg-indigo-600/30 border-indigo-400 text-indigo-200 font-medium'
                        : 'bg-white/[0.02] border-white/[0.06] text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {isSelected && <Check className="w-3 h-3 text-indigo-400" />}
                    #{sym}
                  </button>
                );
              })}
            </div>

            {/* Custom symbol input */}
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={customSymbol}
                onChange={(e) => setCustomSymbol(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddCustomSymbol();
                  }
                }}
                placeholder="Add custom motif tag (e.g. compass, violin)"
                className="flex-1 px-3 py-1.5 text-xs rounded-lg bg-white/[0.03] border border-white/[0.08] text-slate-200 placeholder-slate-400 focus:outline-none focus:border-indigo-500"
              />
              <button
                type="button"
                onClick={handleAddCustomSymbol}
                className="px-3 py-1.5 text-xs font-medium rounded-lg bg-white/[0.05] hover:bg-white/[0.1] text-slate-300 flex items-center gap-1"
              >
                <Plus className="w-3 h-3" />
                Add
              </button>
            </div>
          </div>

          {/* Footer actions */}
          <div className="flex items-center justify-between pt-4 border-t border-white/[0.08]">
            <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
              <span>Posting as: <strong className="text-slate-200">{currentUser.name}</strong></span>
              <span className="text-indigo-400 font-mono">(+5 pts)</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-2 text-xs font-medium rounded-lg bg-white/[0.04] hover:bg-white/[0.08] text-slate-300"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting || !title.trim() || !story.trim()}
                className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white shadow-sm shadow-indigo-600/25 transition-all"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isSubmitting ? 'Logging...' : 'Submit to Community (+5 pts)'}</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

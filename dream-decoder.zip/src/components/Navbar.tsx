import React, { useState } from 'react';
import { Sparkles, Moon, Volume2, VolumeX, Plus, Trophy, BookOpen, Layers, ChevronDown, Check } from 'lucide-react';
import { UserProfile } from '../types.ts';
import { dreamAudio } from '../utils/audio.ts';

interface NavbarProps {
  activeTab: 'feed' | 'lexicon' | 'leaderboard' | 'about';
  setActiveTab: (tab: 'feed' | 'lexicon' | 'leaderboard' | 'about') => void;
  currentUser: UserProfile;
  allUsers: UserProfile[];
  onSelectUser: (user: UserProfile) => void;
  onOpenSubmitDream: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  currentUser,
  allUsers,
  onSelectUser,
  onOpenSubmitDream,
}) => {
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  const toggleSound = () => {
    const playing = dreamAudio.toggle();
    setIsPlayingAudio(playing);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#080911]/90 backdrop-blur-md border-b border-white/[0.08]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand */}
        <div 
          onClick={() => setActiveTab('feed')}
          className="flex items-center gap-3 cursor-pointer group select-none"
        >
          <div className="w-9 h-9 rounded-lg bg-indigo-950/80 border border-indigo-500/30 flex items-center justify-center text-indigo-300 group-hover:border-indigo-400/50 transition-colors shadow-sm shadow-indigo-500/10">
            <Moon className="w-5 h-5 transition-transform group-hover:-rotate-12" />
          </div>
          <div>
            <span className="font-display font-bold text-lg tracking-wider text-slate-100 flex items-center gap-1.5">
              DREAM DECODER
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse" />
            </span>
            <p className="text-[11px] text-slate-400 -mt-1 hidden sm:block font-normal">
              Subconscious Cartography & Archetypal Resonance
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="hidden md:flex items-center gap-1 p-1 bg-white/[0.03] rounded-lg border border-white/[0.06]">
          <button
            onClick={() => setActiveTab('feed')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeTab === 'feed'
                ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/40 shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.03]'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            Dream Feed
          </button>

          <button
            onClick={() => setActiveTab('leaderboard')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeTab === 'leaderboard'
                ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/40 shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.03]'
            }`}
          >
            <Trophy className="w-3.5 h-3.5" />
            Decoder Guild
          </button>

          <button
            onClick={() => setActiveTab('lexicon')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeTab === 'lexicon'
                ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/40 shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.03]'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            Symbol Lexicon
          </button>

          <button
            onClick={() => setActiveTab('about')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeTab === 'about'
                ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/40 shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.03]'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            Point Economy
          </button>
        </nav>

        {/* Actions & Profile Switcher */}
        <div className="flex items-center gap-2.5">
          {/* Ambient Sound Toggle */}
          <button
            onClick={toggleSound}
            title={isPlayingAudio ? 'Mute ambient dream drone' : 'Play ambient theta dream drone'}
            className={`p-2 rounded-lg border transition-all text-xs flex items-center justify-center ${
              isPlayingAudio 
                ? 'bg-indigo-950/60 border-indigo-500/40 text-indigo-300' 
                : 'bg-white/[0.03] border-white/[0.08] text-slate-400 hover:text-slate-200'
            }`}
          >
            {isPlayingAudio ? <Volume2 className="w-4 h-4 animate-pulse" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Submit Dream Button */}
          <button
            onClick={onOpenSubmitDream}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm shadow-indigo-600/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Log Dream</span>
            <span className="sm:hidden">Log</span>
            <span className="text-[10px] text-indigo-200 font-mono hidden md:inline ml-0.5">+5pts</span>
          </button>

          {/* User Switcher Dropdown */}
          <div className="relative">
            <button
              onClick={() => setUserDropdownOpen(!userDropdownOpen)}
              className="flex items-center gap-2 py-1 px-2.5 rounded-lg bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] transition-colors"
            >
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-6 h-6 rounded-full object-cover ring-1 ring-indigo-400/30"
              />
              <div className="text-left hidden lg:block">
                <div className="text-xs font-medium text-slate-200 leading-tight">
                  {currentUser.name}
                </div>
                <div className="text-[10px] text-indigo-300/90 leading-tight">
                  {currentUser.rankName}
                </div>
              </div>
              <div className="bg-indigo-950/90 border border-indigo-500/30 rounded px-1.5 py-0.5 text-[11px] font-mono tabular-nums text-indigo-300 font-semibold ml-0.5">
                {currentUser.points} <span className="text-[9px] font-sans font-normal text-slate-400">pts</span>
              </div>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {userDropdownOpen && (
              <>
                <div 
                  className="fixed inset-0 z-40" 
                  onClick={() => setUserDropdownOpen(false)}
                />
                <div className="absolute right-0 mt-2 w-72 bg-[#0e101f] border border-white/10 rounded-xl shadow-xl shadow-black/60 p-2 z-50">
                  <div className="px-2.5 py-2 border-b border-white/[0.06] mb-1">
                    <p className="text-xs font-semibold text-slate-300">Switch Community Persona</p>
                    <p className="text-[11px] text-slate-400">
                      Switch identities to test interpreting, upvoting, and earning points from different angles.
                    </p>
                  </div>
                  
                  <div className="space-y-1">
                    {allUsers.map((u) => {
                      const isSelected = u.id === currentUser.id;
                      return (
                        <button
                          key={u.id}
                          onClick={() => {
                            onSelectUser(u);
                            setUserDropdownOpen(false);
                          }}
                          className={`w-full flex items-center justify-between p-2 rounded-lg text-left transition-colors ${
                            isSelected 
                              ? 'bg-indigo-950/70 border border-indigo-500/30 text-white' 
                              : 'hover:bg-white/[0.04] text-slate-300'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <img
                              src={u.avatar}
                              alt={u.name}
                              className="w-7 h-7 rounded-full object-cover shrink-0"
                            />
                            <div className="truncate">
                              <p className="text-xs font-medium truncate">{u.name}</p>
                              <p className="text-[10px] text-slate-400 truncate">{u.title}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            <span className="text-xs font-mono tabular-nums text-indigo-300 font-medium">
                              {u.points} pts
                            </span>
                            {isSelected && <Check className="w-3.5 h-3.5 text-indigo-400" />}
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  <div className="mt-2 pt-2 border-t border-white/[0.06] px-2 text-[10px] text-slate-400 flex items-center justify-between">
                    <span>Rank: <span className="text-slate-200">{currentUser.rankName}</span></span>
                    <span>Wins: <span className="text-amber-300 font-mono">{currentUser.winsCount} 👑</span></span>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Nav subbar */}
      <div className="md:hidden flex items-center justify-around border-t border-white/[0.06] bg-[#0b0c17] py-2 px-2 text-xs">
        <button
          onClick={() => setActiveTab('feed')}
          className={`flex items-center gap-1.5 py-1 px-2 rounded-md ${
            activeTab === 'feed' ? 'text-indigo-300 bg-indigo-950/60 font-medium' : 'text-slate-400'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          Feed
        </button>
        <button
          onClick={() => setActiveTab('leaderboard')}
          className={`flex items-center gap-1.5 py-1 px-2 rounded-md ${
            activeTab === 'leaderboard' ? 'text-indigo-300 bg-indigo-950/60 font-medium' : 'text-slate-400'
          }`}
        >
          <Trophy className="w-3.5 h-3.5" />
          Guild
        </button>
        <button
          onClick={() => setActiveTab('lexicon')}
          className={`flex items-center gap-1.5 py-1 px-2 rounded-md ${
            activeTab === 'lexicon' ? 'text-indigo-300 bg-indigo-950/60 font-medium' : 'text-slate-400'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          Lexicon
        </button>
        <button
          onClick={() => setActiveTab('about')}
          className={`flex items-center gap-1.5 py-1 px-2 rounded-md ${
            activeTab === 'about' ? 'text-indigo-300 bg-indigo-950/60 font-medium' : 'text-slate-400'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          Rules
        </button>
      </div>
    </header>
  );
};

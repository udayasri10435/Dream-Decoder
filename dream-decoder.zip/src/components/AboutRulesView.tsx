import React from 'react';
import { Moon, Sparkles, Trophy, Crown, Heart, Compass, Shield, BookOpen, Layers } from 'lucide-react';

export const AboutRulesView: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Hero */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-950/60 border border-indigo-500/30 text-indigo-300 text-xs font-medium mb-3">
          <Sparkles className="w-3.5 h-3.5" />
          The Oneiric Framework
        </div>
        <h1 className="font-display font-bold text-3xl sm:text-4xl text-slate-100 mb-3">
          How Dream Decoder Works
        </h1>
        <p className="text-sm text-slate-300/90 leading-relaxed">
          Dreams are not random static—they are encrypted missives from the collective and personal unconscious.
          Here, dreamers share their nighttime visions, and the community decodes their hidden psychological architecture.
        </p>
      </div>

      {/* 4 Step Process */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-12">
        <div className="p-6 rounded-2xl bg-[#0e101f] border border-white/[0.08]">
          <div className="w-8 h-8 rounded-lg bg-indigo-950/80 border border-indigo-500/30 flex items-center justify-center text-indigo-300 mb-4 font-mono font-bold text-sm">
            01
          </div>
          <h2 className="font-display font-semibold text-lg text-slate-100 mb-2">
            Submit Your Dream Log
          </h2>
          <p className="text-xs text-slate-300/90 leading-relaxed mb-3">
            Record the narrative while fresh. Document sensory details, atmosphere, lucidity scale (1–5), and recurring symbols. You immediately earn <strong className="text-indigo-300 font-mono">+5 points</strong> for logging a dream.
          </p>
          <span className="text-[11px] text-slate-400 font-mono">Reward: +5 points</span>
        </div>

        <div className="p-6 rounded-2xl bg-[#0e101f] border border-white/[0.08]">
          <div className="w-8 h-8 rounded-lg bg-indigo-950/80 border border-indigo-500/30 flex items-center justify-center text-indigo-300 mb-4 font-mono font-bold text-sm">
            02
          </div>
          <h2 className="font-display font-semibold text-lg text-slate-100 mb-2">
            Community Decode & Lenses
          </h2>
          <p className="text-xs text-slate-300/90 leading-relaxed mb-3">
            Community members examine your dream through Jungian archetypes (Shadow, Anima, Self), Depth Psychology, Mythic folklore, or Subconscious memory processing. Sharing an interpretation awards <strong className="text-indigo-300 font-mono">+15 points</strong>.
          </p>
          <span className="text-[11px] text-slate-400 font-mono">Reward: +15 base points</span>
        </div>

        <div className="p-6 rounded-2xl bg-[#0e101f] border border-white/[0.08]">
          <div className="w-8 h-8 rounded-lg bg-indigo-950/80 border border-indigo-500/30 flex items-center justify-center text-indigo-300 mb-4 font-mono font-bold text-sm">
            03
          </div>
          <h2 className="font-display font-semibold text-lg text-slate-100 mb-2">
            Resonance & Upvoting
          </h2>
          <p className="text-xs text-slate-300/90 leading-relaxed mb-3">
            The community votes on interpretations that feel genuinely truthful, empathetic, and penetrating. Every "Resonate" like earns the interpreter <strong className="text-indigo-300 font-mono">+10 points</strong>.
          </p>
          <span className="text-[11px] text-slate-400 font-mono">Reward: +10 points per vote</span>
        </div>

        <div className="p-6 rounded-2xl bg-[#0e101f] border border-amber-500/30 bg-amber-950/10">
          <div className="w-8 h-8 rounded-lg bg-amber-950/80 border border-amber-500/40 flex items-center justify-center text-amber-300 mb-4 font-mono font-bold text-sm">
            04
          </div>
          <h2 className="font-display font-semibold text-lg text-amber-200 mb-2 flex items-center gap-1.5">
            <Crown className="w-4 h-4 text-amber-400" />
            The Dreamer's Crown
          </h2>
          <p className="text-xs text-slate-300/90 leading-relaxed mb-3">
            The original dreamer can crown the single interpretation that provided their greatest "aha!" epiphany. The winner receives a massive <strong className="text-amber-300 font-mono">+50 bonus points</strong> and a crowned win tally!
          </p>
          <span className="text-[11px] text-amber-400 font-mono">Bonus: +50 winner points</span>
        </div>
      </div>

      {/* Ranks & Progression */}
      <div className="p-6 sm:p-8 rounded-2xl bg-[#0e101f] border border-white/[0.08] mb-12">
        <h2 className="font-display font-semibold text-xl text-slate-100 mb-4 flex items-center gap-2">
          <Trophy className="w-5 h-5 text-indigo-400" />
          The Oneironaut Hierarchy
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 text-center">
          <div className="p-3.5 rounded-xl bg-white/[0.02] border border-white/[0.06]">
            <div className="text-xs font-semibold text-slate-300 mb-1">Novice</div>
            <div className="text-[11px] font-mono text-indigo-300">0 - 49 pts</div>
            <p className="text-[10px] text-slate-400 mt-1">Starting observer</p>
          </div>
          <div className="p-3.5 rounded-xl bg-white/[0.02] border border-white/[0.06]">
            <div className="text-xs font-semibold text-slate-300 mb-1">Lucid Wanderer</div>
            <div className="text-[11px] font-mono text-indigo-300">50 - 199 pts</div>
            <p className="text-[10px] text-slate-400 mt-1">Aware interpreter</p>
          </div>
          <div className="p-3.5 rounded-xl bg-white/[0.02] border border-white/[0.06]">
            <div className="text-xs font-semibold text-slate-300 mb-1">Archetype Weaver</div>
            <div className="text-[11px] font-mono text-indigo-300">200 - 499 pts</div>
            <p className="text-[10px] text-slate-400 mt-1">Master of symbols</p>
          </div>
          <div className="p-3.5 rounded-xl bg-white/[0.02] border border-white/[0.06]">
            <div className="text-xs font-semibold text-slate-300 mb-1">Psychologist</div>
            <div className="text-[11px] font-mono text-indigo-300">500 - 999 pts</div>
            <p className="text-[10px] text-slate-400 mt-1">Deep subconscious guide</p>
          </div>
          <div className="p-3.5 rounded-xl bg-amber-950/20 border border-amber-500/30">
            <div className="text-xs font-bold text-amber-300 mb-1 flex items-center justify-center gap-1">
              <Crown className="w-3.5 h-3.5 text-amber-400" />
              Grand Oracle
            </div>
            <div className="text-[11px] font-mono text-amber-400">1,000+ pts</div>
            <p className="text-[10px] text-slate-400 mt-1">Highest resonance</p>
          </div>
        </div>
      </div>

      {/* Community Ethics */}
      <div className="p-6 rounded-2xl bg-indigo-950/20 border border-indigo-500/20 text-xs text-slate-300 leading-relaxed space-y-2">
        <h3 className="font-semibold text-slate-100 text-sm flex items-center gap-2">
          <Shield className="w-4 h-4 text-indigo-400" />
          The Oneiric Ethos & Guidelines
        </h3>
        <p>
          • <strong>Interpret with Empathy:</strong> Treat every dream narrative as sacred emotional vulnerability. Offer questions and insights, not dogmatic diagnoses.
        </p>
        <p>
          • <strong>Focus on Metaphor:</strong> Look beyond literal fear or violence to discover what the subconscious is attempting to balance or transcend.
        </p>
        <p>
          • <strong>The Dreamer is the Ultimate Authority:</strong> An interpretation is only true if it clicks deep within the dreamer's own intuition.
        </p>
      </div>
    </div>
  );
};

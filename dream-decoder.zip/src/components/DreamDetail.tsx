import React, { useState } from 'react';
import { 
  ArrowLeft, Heart, Crown, Sparkles, MessageSquare, Compass, 
  Send, AlertCircle, CheckCircle2, BookOpen, User, Flame
} from 'lucide-react';
import { Dream, Interpretation, UserProfile, SchoolOfThought, DreamSymbolItem } from '../types.ts';
import { DREAM_SYMBOLS } from '../data/symbols.ts';

interface DreamDetailProps {
  dream: Dream;
  currentUser: UserProfile;
  onBack: () => void;
  onVoteInterpretation: (interpretationId: string) => Promise<void>;
  onCrownWinner: (interpretationId: string) => Promise<void>;
  onSubmitInterpretation: (data: {
    content: string;
    schoolOfThought: SchoolOfThought;
    symbolsAddressed: string[];
    reflectionPrompt: string;
  }) => Promise<void>;
  onConsultOracle: () => Promise<void>;
  isConsultingOracle: boolean;
}

export const DreamDetail: React.FC<DreamDetailProps> = ({
  dream,
  currentUser,
  onBack,
  onVoteInterpretation,
  onCrownWinner,
  onSubmitInterpretation,
  onConsultOracle,
  isConsultingOracle,
}) => {
  // Interpretation form state
  const [interpContent, setInterpContent] = useState('');
  const [schoolOfThought, setSchoolOfThought] = useState<SchoolOfThought>('Jungian Archetype');
  const [reflectionPrompt, setReflectionPrompt] = useState('');
  const [selectedSymbols, setSelectedSymbols] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState<string | null>(null);

  // Selected symbol definition modal/drawer
  const [inspectSymbol, setInspectSymbol] = useState<DreamSymbolItem | null>(null);

  // Sorting interpretations
  const [sortMode, setSortMode] = useState<'resonant' | 'newest'>('resonant');

  const isDreamOwner = currentUser.id === dream.authorId;

  // Sort interpretations
  const sortedInterpretations = [...dream.interpretations].sort((a, b) => {
    if (sortMode === 'resonant') {
      // Crowned or most upvotes first
      if (a.isDreamerCrowned && !b.isDreamerCrowned) return -1;
      if (!a.isDreamerCrowned && b.isDreamerCrowned) return 1;
      return b.upvotes - a.upvotes;
    }
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!interpContent.trim()) return;

    try {
      setIsSubmitting(true);
      await onSubmitInterpretation({
        content: interpContent.trim(),
        schoolOfThought,
        symbolsAddressed: selectedSymbols,
        reflectionPrompt: reflectionPrompt.trim(),
      });
      setInterpContent('');
      setReflectionPrompt('');
      setSelectedSymbols([]);
      setSubmitSuccess('Interpretation shared! You earned +15 points.');
      setTimeout(() => setSubmitSuccess(null), 5000);
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSymbolClick = (symKeyword: string) => {
    const found = DREAM_SYMBOLS.find(s => 
      s.keywords.some(k => k.toLowerCase() === symKeyword.toLowerCase()) ||
      s.name.toLowerCase().includes(symKeyword.toLowerCase())
    );
    if (found) {
      setInspectSymbol(found);
    } else {
      setInspectSymbol({
        id: symKeyword,
        name: symKeyword.charAt(0).toUpperCase() + symKeyword.slice(1),
        category: 'Objects & Relics',
        archetype: 'The Enigmatic Cipher',
        meaning: `A recurring subconscious element specific to the dreamer's personal iconography. Represents a focal point of emotional charge in "${dream.title}".`,
        jungianNote: 'Personal symbols often act as tailored bridge-points connecting waking complexes to deeper archetypal realities.',
        keywords: [symKeyword]
      });
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Back button */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-xs font-medium text-slate-400 hover:text-slate-100 transition-colors mb-6 group"
      >
        <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
        Return to Dream Feed
      </button>

      {/* Main Dream Narrative Article */}
      <article className="bg-[#0e101f]/90 border border-white/[0.08] rounded-2xl p-6 sm:p-8 shadow-xl shadow-black/40 mb-10">
        {/* Dream Header / Metadata */}
        <div className="flex flex-wrap items-center justify-between gap-y-2 gap-x-4 border-b border-white/[0.08] pb-5 mb-6 text-xs text-slate-400">
          <div className="flex items-center gap-3">
            <img
              src={dream.authorAvatar}
              alt={dream.authorName}
              className="w-10 h-10 rounded-full object-cover ring-2 ring-indigo-500/30"
            />
            <div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-100 text-sm">{dream.authorName}</span>
                {isDreamOwner && (
                  <span className="text-[10px] text-indigo-300 font-mono">
                    (You are the Dreamer)
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400">{dream.authorTitle}</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-slate-400">
            <span>{new Date(dream.createdAt).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</span>
            <span aria-hidden="true">·</span>
            <span className="text-indigo-300 font-medium">{dream.mood}</span>
            <span aria-hidden="true">·</span>
            <span>{dream.sleepStage}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-slate-300">Lucidity {dream.lucidityLevel}/5</span>
          </div>
        </div>

        {/* Title */}
        <h1 className="font-display font-bold text-2xl sm:text-3xl text-slate-100 mb-6 leading-tight">
          {dream.title}
        </h1>

        {/* Story Prose */}
        <div className="text-base sm:text-lg text-slate-200/90 leading-relaxed space-y-4 whitespace-pre-line font-serif italic mb-8">
          {dream.story}
        </div>

        {/* Motifs / Symbols bar with dictionary click */}
        {dream.recurringSymbols.length > 0 && (
          <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.06] mb-6">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-300 mb-2">
              <BookOpen className="w-4 h-4 text-indigo-400" />
              <span>Recurring Oneiric Motifs (Click to inspect archetypal meaning):</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {dream.recurringSymbols.map((sym) => (
                <button
                  key={sym}
                  type="button"
                  onClick={() => handleSymbolClick(sym)}
                  className="px-2.5 py-1 text-xs rounded-md bg-indigo-950/40 hover:bg-indigo-900/60 border border-indigo-500/20 hover:border-indigo-400/40 text-indigo-300 transition-colors cursor-pointer"
                >
                  #{sym}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Consult the Oracle Callout */}
        <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-white/[0.06]">
          <div className="text-xs text-slate-400">
            <span className="text-slate-200 font-medium">Community Decoders: </span>
            {dream.interpretations.length} decoders competing for resonance points.
          </div>

          <button
            onClick={onConsultOracle}
            disabled={isConsultingOracle}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg bg-purple-950/50 hover:bg-purple-900/50 text-purple-200 border border-purple-500/30 hover:border-purple-400/50 shadow-sm transition-all"
          >
            <Compass className={`w-4 h-4 text-purple-400 ${isConsultingOracle ? 'animate-spin' : ''}`} />
            {isConsultingOracle 
              ? 'Channeling Oracle Archetypes...' 
              : dream.oracleAnalysis 
                ? 'View Oracle Jungian Reading' 
                : 'Consult the Oracle (AI Jungian Analysis)'}
          </button>
        </div>
      </article>

      {/* AI Oracle Chamber Breakdown (if generated) */}
      {dream.oracleAnalysis && (
        <section className="mb-10 p-6 sm:p-8 rounded-2xl bg-gradient-to-b from-[#13112b] to-[#0c0d1c] border border-purple-500/30 shadow-2xl relative overflow-hidden">
          <div className="flex items-center justify-between mb-4 border-b border-purple-500/20 pb-3">
            <div className="flex items-center gap-2.5">
              <Compass className="w-5 h-5 text-purple-400" />
              <h2 className="font-display font-semibold text-lg text-purple-100">
                The Oracle's Archetypal Reading
              </h2>
            </div>
            <span className="text-[11px] font-mono text-purple-300/70">
              Depth Psychology Synthesis
            </span>
          </div>

          <p className="text-sm text-purple-200/90 italic mb-6 leading-relaxed">
            "{dream.oracleAnalysis.summary}"
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            {dream.oracleAnalysis.archetypes.map((arch, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-purple-950/30 border border-purple-500/20">
                <p className="text-xs font-semibold text-purple-300 mb-1">{arch.name}</p>
                <p className="text-xs text-slate-300 mb-2 leading-relaxed">{arch.description}</p>
                <p className="text-[11px] text-purple-400/90 leading-tight">
                  <span className="font-semibold text-purple-300">Psychological Task:</span> {arch.meaning}
                </p>
              </div>
            ))}
          </div>

          <div className="space-y-3 text-xs text-slate-300 border-t border-purple-500/20 pt-4">
            <div>
              <span className="font-semibold text-purple-300">Shadow Reflection: </span>
              {dream.oracleAnalysis.shadowSelfReflection}
            </div>
            <div>
              <span className="font-semibold text-purple-300">Unconscious Tension: </span>
              {dream.oracleAnalysis.unconsciousTension}
            </div>
            <div className="p-3 rounded-lg bg-black/30 border border-purple-400/20 text-purple-200 font-serif italic text-sm">
              <span className="not-italic font-sans text-xs font-semibold text-purple-300 block mb-1">
                Guided Inquiry for the Dreamer:
              </span>
              "{dream.oracleAnalysis.guidedInquiry}"
            </div>
          </div>
        </section>
      )}

      {/* Community Interpretations Section */}
      <section className="mb-12">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="font-display font-semibold text-xl text-slate-100 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-indigo-400" />
              Community Decodes
              <span className="text-sm font-sans font-normal text-slate-400">
                ({dream.interpretations.length})
              </span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Upvote interpretations that resonate. Most-liked decodes win points and climb the Guild ranks!
            </p>
          </div>

          {/* Sort tabs */}
          <div className="flex items-center gap-1 p-1 bg-white/[0.03] rounded-lg border border-white/[0.06]">
            <button
              onClick={() => setSortMode('resonant')}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                sortMode === 'resonant'
                  ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Most Resonant
            </button>
            <button
              onClick={() => setSortMode('newest')}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                sortMode === 'newest'
                  ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Newest
            </button>
          </div>
        </div>

        {/* Interpretations List */}
        {dream.interpretations.length === 0 ? (
          <div className="p-8 rounded-xl bg-white/[0.02] border border-dashed border-white/10 text-center">
            <Sparkles className="w-8 h-8 text-indigo-400/60 mx-auto mb-3" />
            <p className="text-sm font-medium text-slate-200 mb-1">
              No one has decoded this dream yet
            </p>
            <p className="text-xs text-slate-400 max-w-md mx-auto mb-4">
              Be the first oneironaut to submit an interpretation below. You will earn +15 base points, plus +10 for every user who resonates!
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {sortedInterpretations.map((interp, index) => {
              const hasUpvoted = interp.upvotedBy.includes(currentUser.id);
              const isWinner = dream.crownedInterpretationId === interp.id;
              const isLeadVote = index === 0 && interp.upvotes > 0;

              return (
                <div
                  key={interp.id}
                  className={`p-5 sm:p-6 rounded-xl border transition-all ${
                    isWinner 
                      ? 'bg-amber-950/25 border-amber-500/40 shadow-lg shadow-amber-950/30' 
                      : isLeadVote
                        ? 'bg-[#101224] border-indigo-500/30'
                        : 'bg-[#0e101f] border-white/[0.07]'
                  }`}
                >
                  {/* Top Badge: Winner or Lead */}
                  {isWinner && (
                    <div className="flex items-center gap-2 mb-3 pb-2.5 border-b border-amber-500/20 text-xs font-semibold text-amber-300">
                      <Crown className="w-4 h-4 text-amber-400" />
                      <span>Dreamer's Crowned Epiphany (+50 Pts Bonus Winner)</span>
                    </div>
                  )}

                  {!isWinner && isLeadVote && (
                    <div className="flex items-center gap-2 mb-3 pb-2.5 border-b border-indigo-500/20 text-xs font-medium text-indigo-300">
                      <Flame className="w-4 h-4 text-amber-400" />
                      <span>Current Points Leader ({interp.pointsAwarded} pts earned)</span>
                    </div>
                  )}

                  {/* Header: Author Info & School of Thought */}
                  <div className="flex flex-wrap items-center justify-between gap-y-2 gap-x-4 mb-3 text-xs">
                    <div className="flex items-center gap-2.5">
                      <img
                        src={interp.authorAvatar}
                        alt={interp.authorName}
                        className="w-7 h-7 rounded-full object-cover ring-1 ring-white/10"
                      />
                      <div>
                        <span className="font-semibold text-slate-200">{interp.authorName}</span>
                        <span className="text-[11px] text-slate-400 ml-2">{interp.authorTitle}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 text-[11px] text-slate-400">
                      <span className="text-indigo-300 font-medium">{interp.schoolOfThought}</span>
                      <span aria-hidden="true">·</span>
                      <span>{new Date(interp.createdAt).toLocaleDateString()}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono text-indigo-300 tabular-nums font-semibold">
                        +{interp.pointsAwarded} pts
                      </span>
                    </div>
                  </div>

                  {/* Interpretation Content */}
                  <div className="text-sm text-slate-200 leading-relaxed mb-4 whitespace-pre-line">
                    {interp.content}
                  </div>

                  {/* Reflection Prompt / Question back to dreamer */}
                  {interp.reflectionPrompt && (
                    <div className="p-3 rounded-lg bg-white/[0.02] border border-white/[0.05] text-xs text-slate-300 mb-4">
                      <span className="font-semibold text-indigo-300 block mb-0.5">
                        Inquiry for the Dreamer:
                      </span>
                      <span className="italic">"{interp.reflectionPrompt}"</span>
                    </div>
                  )}

                  {/* Action Bar: Resonate/Like & Dreamer Crown Button */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-white/[0.06] text-xs">
                    {/* Upvote / Resonate Button */}
                    <button
                      onClick={() => onVoteInterpretation(interp.id)}
                      className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border transition-all ${
                        hasUpvoted
                          ? 'bg-rose-950/60 border-rose-500/40 text-rose-200 shadow-sm'
                          : 'bg-white/[0.03] border-white/[0.08] text-slate-300 hover:bg-white/[0.06] hover:text-white'
                      }`}
                    >
                      <Heart 
                        className={`w-3.5 h-3.5 ${hasUpvoted ? 'fill-rose-400 text-rose-400' : 'text-slate-400'}`} 
                      />
                      <span className="font-medium font-mono tabular-nums">{interp.upvotes}</span>
                      <span>{hasUpvoted ? 'Resonated' : 'Resonate'}</span>
                      <span className="text-[10px] text-slate-400 font-mono">(+10pts)</span>
                    </button>

                    {/* Dreamer Crown Action */}
                    {isDreamOwner && (
                      <button
                        onClick={() => onCrownWinner(interp.id)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium transition-all ${
                          isWinner
                            ? 'bg-amber-600 text-white border-amber-400 shadow-sm shadow-amber-500/20'
                            : 'bg-amber-950/40 border-amber-500/30 text-amber-200 hover:bg-amber-900/50'
                        }`}
                      >
                        <Crown className="w-3.5 h-3.5" />
                        <span>{isWinner ? 'Epiphany Crowned' : 'Crown as Winning Epiphany (+50 pts)'}</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Submit Your Interpretation Form */}
      <section className="bg-[#0e101f] border border-white/[0.08] rounded-2xl p-6 sm:p-8">
        <div className="flex items-center justify-between mb-4 border-b border-white/[0.06] pb-3">
          <div>
            <h3 className="font-display font-semibold text-lg text-slate-100 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              Offer Your Interpretation
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Contributing an insightful decode awards you <span className="text-indigo-300 font-mono font-medium">+15 points</span>, plus <span className="text-indigo-300 font-mono font-medium">+10 points</span> per community like.
            </p>
          </div>
          <div className="text-right hidden sm:block">
            <span className="text-[11px] text-slate-400 block">Decoding as:</span>
            <span className="text-xs font-medium text-slate-200">{currentUser.name}</span>
          </div>
        </div>

        {submitSuccess && (
          <div className="mb-4 p-3 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-emerald-200 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{submitSuccess}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* School of Thought */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                School of Thought / Lens
              </label>
              <select
                value={schoolOfThought}
                onChange={(e) => setSchoolOfThought(e.target.value as SchoolOfThought)}
                className="w-full px-3 py-2 text-xs rounded-lg bg-white/[0.03] border border-white/[0.08] text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
              >
                <option value="Jungian Archetype" className="bg-[#121424]">Jungian Archetype (Shadow, Anima, Self)</option>
                <option value="Depth Psychology" className="bg-[#121424]">Depth Psychology (Unconscious Motives)</option>
                <option value="Mythic & Folkloric" className="bg-[#121424]">Mythic & Folkloric (Universal Legends)</option>
                <option value="Subconscious Processing" className="bg-[#121424]">Subconscious Processing (Stress/Memory)</option>
                <option value="Lucid Reflection" className="bg-[#121424]">Lucid Reflection (Waking Awareness)</option>
              </select>
            </div>

            {/* Inquiring prompt to the dreamer */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Inquiry Question for the Dreamer (Optional)
              </label>
              <input
                type="text"
                value={reflectionPrompt}
                onChange={(e) => setReflectionPrompt(e.target.value)}
                placeholder="e.g. What recent event made you feel unheard?"
                className="w-full px-3 py-2 text-xs rounded-lg bg-white/[0.03] border border-white/[0.08] text-slate-200 placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition-colors"
              />
            </div>
          </div>

          {/* Detailed Interpretation Textarea */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Your Archetypal & Psychological Analysis
            </label>
            <textarea
              required
              rows={5}
              value={interpContent}
              onChange={(e) => setInterpContent(e.target.value)}
              placeholder="Examine the core metaphors, emotional currents, and hidden messages. What is the dreamer's unconscious trying to bring into the light?"
              className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-lg bg-white/[0.03] border border-white/[0.08] text-slate-200 placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition-colors leading-relaxed"
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <span className="text-[11px] text-slate-400">
              Thoughtful interpretations that cite symbols and offer genuine questions receive the highest votes.
            </span>

            <button
              type="submit"
              disabled={isSubmitting || !interpContent.trim()}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white transition-all shadow-sm shadow-indigo-600/20"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isSubmitting ? 'Submitting...' : 'Submit Decode (+15 pts)'}</span>
            </button>
          </div>
        </form>
      </section>

      {/* Symbol Modal / Drawer */}
      {inspectSymbol && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-[#121426] border border-indigo-500/30 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
            <div className="flex items-center justify-between pb-3 border-b border-white/[0.08] mb-4">
              <div>
                <span className="text-[10px] text-indigo-400 font-mono uppercase tracking-wider block">
                  {inspectSymbol.category}
                </span>
                <h3 className="font-display font-semibold text-lg text-slate-100">
                  {inspectSymbol.name}
                </h3>
              </div>
              <button
                onClick={() => setInspectSymbol(null)}
                className="text-slate-400 hover:text-white p-1 rounded-md text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs leading-relaxed text-slate-300">
              <div>
                <span className="font-semibold text-indigo-300 block mb-0.5">Core Archetype:</span>
                <p className="text-slate-200">{inspectSymbol.archetype}</p>
              </div>

              <div>
                <span className="font-semibold text-indigo-300 block mb-0.5">Universal Meaning:</span>
                <p>{inspectSymbol.meaning}</p>
              </div>

              <div className="p-3 rounded-lg bg-indigo-950/30 border border-indigo-500/20 text-indigo-200">
                <span className="font-semibold text-indigo-300 block mb-0.5">Jungian Depth Perspective:</span>
                <p className="italic">{inspectSymbol.jungianNote}</p>
              </div>
            </div>

            <div className="mt-5 pt-3 border-t border-white/[0.08] text-right">
              <button
                onClick={() => setInspectSymbol(null)}
                className="px-3.5 py-1.5 text-xs font-medium rounded-lg bg-white/[0.05] hover:bg-white/[0.1] text-slate-200"
              >
                Close Lexicon
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export type DreamMood = 
  | 'Ethereal'
  | 'Nightmarish'
  | 'Lucid'
  | 'Mystical'
  | 'Surreal'
  | 'Nostalgic'
  | 'Prophetic'
  | 'Anxious';

export type SleepStage = 
  | 'Deep REM' 
  | 'Hypnagogic' 
  | 'Morning Twilight' 
  | 'False Awakening';

export type SchoolOfThought = 
  | 'Jungian Archetype'
  | 'Depth Psychology'
  | 'Mythic & Folkloric'
  | 'Subconscious Processing'
  | 'Lucid Reflection';

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  tier: 'bronze' | 'silver' | 'gold' | 'celestial';
}

export interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  title: string;
  bio: string;
  points: number;
  level: number;
  rankName: string;
  interpretationsCount: number;
  winsCount: number;
  dreamsSubmitted: number;
  badges: Badge[];
}

export interface Interpretation {
  id: string;
  dreamId: string;
  authorId: string;
  authorName: string;
  authorTitle: string;
  authorAvatar: string;
  content: string;
  schoolOfThought: SchoolOfThought;
  symbolsAddressed: string[];
  reflectionPrompt?: string;
  upvotes: number;
  upvotedBy: string[];
  isDreamerCrowned: boolean;
  pointsAwarded: number;
  createdAt: string;
  isAiGenerated?: boolean;
}

export interface OracleAnalysis {
  summary: string;
  archetypes: Array<{
    name: string;
    description: string;
    meaning: string;
  }>;
  shadowSelfReflection: string;
  unconsciousTension: string;
  guidedInquiry: string;
}

export interface Dream {
  id: string;
  title: string;
  story: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  authorTitle: string;
  mood: DreamMood;
  lucidityLevel: number; // 1 to 5
  sleepStage: SleepStage;
  recurringSymbols: string[];
  interpretations: Interpretation[];
  crownedInterpretationId?: string | null;
  views: number;
  createdAt: string;
  oracleAnalysis?: OracleAnalysis;
}

export interface DreamSymbolItem {
  id: string;
  name: string;
  category: 'Nature & Elements' | 'Structures & Spaces' | 'Creatures & Beasts' | 'Motions & States' | 'Objects & Relics';
  archetype: string;
  meaning: string;
  jungianNote: string;
  keywords: string[];
}

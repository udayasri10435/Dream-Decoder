import { Dream, UserProfile } from '../types.ts';

export const INITIAL_USERS: UserProfile[] = [
  {
    id: 'user-rowan',
    name: 'Rowan Night',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
    title: 'Lucid Cartographer',
    bio: 'Tracking recurring symbols across hypnagogic and REM states. Fascinated by threshold dreams.',
    points: 135,
    level: 2,
    rankName: 'Lucid Wanderer',
    interpretationsCount: 4,
    winsCount: 1,
    dreamsSubmitted: 2,
    badges: [
      { id: 'b1', name: 'First Epiphany', description: 'Had an interpretation crowned by a dreamer', icon: 'crown', tier: 'silver' },
      { id: 'b2', name: 'Lucid Spark', description: 'Logged a high-lucidity dream', icon: 'sparkle', tier: 'bronze' }
    ]
  },
  {
    id: 'user-alistair',
    name: 'Dr. Alistair Finch',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
    title: 'Depth Psychologist & Scholar',
    bio: 'Thirty years examining archetypal symbolism, shadow integration, and mythopoetic imagery.',
    points: 1480,
    level: 5,
    rankName: 'Grand Oracle',
    interpretationsCount: 78,
    winsCount: 22,
    dreamsSubmitted: 9,
    badges: [
      { id: 'b3', name: 'Grand Sovereign', description: 'Surpassed 1,000 community resonance points', icon: 'award', tier: 'celestial' },
      { id: 'b4', name: 'Jungian Sage', description: 'Awarded 20+ top-voted interpretations', icon: 'book', tier: 'gold' }
    ]
  },
  {
    id: 'user-elena',
    name: 'Elena Rostova',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=150&q=80',
    title: 'Mythic Folklorist',
    bio: 'Deciphering European and Slavic folklore embedded in contemporary oneiric narratives.',
    points: 860,
    level: 4,
    rankName: 'Depth Psychologist',
    interpretationsCount: 42,
    winsCount: 14,
    dreamsSubmitted: 5,
    badges: [
      { id: 'b5', name: 'Resonance Anchor', description: '10 interpretations with over 15 upvotes', icon: 'anchor', tier: 'gold' },
      { id: 'b6', name: 'Myth Weaver', description: 'Specialist in ancient mythos motifs', icon: 'feather', tier: 'silver' }
    ]
  },
  {
    id: 'user-kaelen',
    name: 'Kaelen Vane',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80',
    title: 'Archetypal Symbolist',
    bio: 'Mapping the tension between conscious persona masks and unconscious nocturnal beasts.',
    points: 420,
    level: 3,
    rankName: 'Archetype Weaver',
    interpretationsCount: 24,
    winsCount: 6,
    dreamsSubmitted: 4,
    badges: [
      { id: 'b7', name: 'Rising Seer', description: 'Earned 400+ points in decodes', icon: 'compass', tier: 'silver' }
    ]
  },
  {
    id: 'user-sora',
    name: 'Sora Lin',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80',
    title: 'Oneiric Artist',
    bio: 'Painting nocturnal visions. Seeking the colors that only exist behind closed eyes.',
    points: 190,
    level: 2,
    rankName: 'Lucid Wanderer',
    interpretationsCount: 11,
    winsCount: 2,
    dreamsSubmitted: 7,
    badges: [
      { id: 'b8', name: 'Vivid Chronicler', description: 'Submitted 5 detailed dream logs', icon: 'feather', tier: 'bronze' }
    ]
  }
];

export const INITIAL_DREAMS: Dream[] = [
  {
    id: 'dream-1',
    title: 'The Submerged Subway with Clocks in Place of Faces',
    story: `I boarded an underground train at midnight. The car was slowly filling with warm, crystalline seawater up to our ankles, but nobody seemed perturbed. All the passengers wore tailored gray coats, but when they turned toward me, their faces were antique brass clock faces. 

Every clock was ticking backward at different speeds. The conductor walked down the aisle checking tickets made of thin dried leaves. When I handed him mine, he whispered: 'You are three minutes earlier than your regret.' The train then accelerated through a tunnel lined with submerged stained-glass cathedral windows.`,
    authorId: 'user-sora',
    authorName: 'Sora Lin',
    authorAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80',
    authorTitle: 'Oneiric Artist',
    mood: 'Surreal',
    lucidityLevel: 4,
    sleepStage: 'Deep REM',
    recurringSymbols: ['train', 'water', 'clocks', 'ocean'],
    views: 342,
    createdAt: '2026-09-27T04:15:00Z',
    crownedInterpretationId: 'interp-1',
    interpretations: [
      {
        id: 'interp-1',
        dreamId: 'dream-1',
        authorId: 'user-alistair',
        authorName: 'Dr. Alistair Finch',
        authorTitle: 'Depth Psychologist & Scholar',
        authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
        content: `This dream manifests an encounter with the Collective Unconscious (the subterranean train moving through ancient waters) colliding with Chronos / Linear Time anxiety.

The passengers with clock faces running backward represent societal expectations of progress that your psyche feels are inherently artificial or retrospective. Notice that the water is crystalline and ankle-deep—this indicates emotional depth that is not yet terrifying, but gently inviting you into reflection. 

The conductor's whisper is the crux: 'You are three minutes earlier than your regret.' Your unconscious is telling you that you still hold agency before a major decision solidifies into grief. The cathedral windows underwater show that what you once held sacred is being preserved, not lost, beneath the surface.`,
        schoolOfThought: 'Jungian Archetype',
        symbolsAddressed: ['water', 'clocks', 'train'],
        reflectionPrompt: 'What decision from the past month are you preemptively mourning before it has even finalized?',
        upvotes: 28,
        upvotedBy: ['user-rowan', 'user-elena', 'user-kaelen'],
        isDreamerCrowned: true,
        pointsAwarded: 345, // 15 base + 28*10 + 50 winner
        createdAt: '2026-09-27T06:30:00Z'
      },
      {
        id: 'interp-2',
        dreamId: 'dream-1',
        authorId: 'user-elena',
        authorName: 'Elena Rostova',
        authorTitle: 'Mythic Folklorist',
        authorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=150&q=80',
        content: `In ancient underworld journeys (the descent to the realm of Hades or the Slavic nav), souls travel across subterranean rivers like the Styx or the Smorodina. The dried leaf ticket evokes the Sibyl of Cumae writing oracles on autumn leaves that scatter in the wind.

You are being asked to pay your fare not with modern currency or accomplishments, but with ephemeral, organic surrender (the leaf). The cathedral windows illuminate this as an initiation passage into a deeper creative cycle.`,
        schoolOfThought: 'Mythic & Folkloric',
        symbolsAddressed: ['train', 'water'],
        reflectionPrompt: 'Are you trying to negotiate your creative path using purely rational, bureaucratic rules?',
        upvotes: 16,
        upvotedBy: ['user-rowan', 'user-sora'],
        isDreamerCrowned: false,
        pointsAwarded: 175,
        createdAt: '2026-09-27T08:12:00Z'
      }
    ],
    oracleAnalysis: {
      summary: 'A classic underworld descent navigating temporal anxiety and spiritual longing.',
      archetypes: [
        { name: 'The Underworld Ferryman (The Conductor)', description: 'Guide across psychological thresholds.', meaning: 'Demands authentic sacrifice rather than ego posturing.' },
        { name: 'Submerged Cathedral (The Lost Sacred)', description: 'Sunken spiritual sanctuaries within the mind.', meaning: 'Faith or deeply held principles currently submerged in emotional turbulence.' }
      ],
      shadowSelfReflection: 'The fear that linear waking time is running out while the emotional self remains trapped in unprocessed past cycles.',
      unconsciousTension: 'The desire to control the schedule versus the tide of organic destiny.',
      guidedInquiry: 'Where in your life are you treating a sacred emotional awakening like a train you might be late for?'
    }
  },
  {
    id: 'dream-2',
    title: 'The Obsidian Tower Guarded by the Mirror Panther',
    story: `I stood before a monolith tower carved from black volcanic glass in an expanse of violet dunes. The door was locked with three horizontal slots resembling piano keys.

As I approached, a panther with fur like liquid mercury stepped out of the shadow. Instead of a predator's face, its face was a mirror reflecting not my current body, but an older, crowned version of myself holding a golden compass. The panther didn't growl; it purred with the sound of a cello chord. I reached for the piano keys on the door, but woke up before pressing them.`,
    authorId: 'user-rowan',
    authorName: 'Rowan Night',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
    authorTitle: 'Lucid Cartographer',
    mood: 'Mystical',
    lucidityLevel: 5,
    sleepStage: 'Morning Twilight',
    recurringSymbols: ['tower', 'mirror', 'beast', 'keys'],
    views: 289,
    createdAt: '2026-09-27T14:20:00Z',
    crownedInterpretationId: null, // Open contest for winning decode!
    interpretations: [
      {
        id: 'interp-3',
        dreamId: 'dream-2',
        authorId: 'user-kaelen',
        authorName: 'Kaelen Vane',
        authorTitle: 'Archetypal Symbolist',
        authorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80',
        content: `The panther is your Shadow, but a benign, highly evolved one—the Instinctual Guardian. Often we fear the beast within, but here it purrs with harmonic resonance (the cello chord) and holds the Mirror of Potentiality.

The reflection of your future crowned self with a golden compass signifies Individuation: sovereignty over your internal moral coordinates. The three piano keys on the door indicate that entry into this next stage of maturity requires harmony and creative expression (sound/keys), rather than brute intellectual force or logic.`,
        schoolOfThought: 'Jungian Archetype',
        symbolsAddressed: ['mirror', 'beast', 'tower', 'keys'],
        reflectionPrompt: 'What creative or instinctual side of yourself have you kept locked away because you feared it was too intense?',
        upvotes: 21,
        upvotedBy: ['user-alistair', 'user-elena'],
        isDreamerCrowned: false,
        pointsAwarded: 225,
        createdAt: '2026-09-27T16:00:00Z'
      },
      {
        id: 'interp-4',
        dreamId: 'dream-2',
        authorId: 'user-alistair',
        authorName: 'Dr. Alistair Finch',
        authorTitle: 'Depth Psychologist & Scholar',
        authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
        content: `The number three is archetypally significant: thesis, antithesis, and synthesis. Three piano keys denote finding resolution between two opposites (perhaps career vs inner calling, or caution vs wildness).

The obsidian tower is your core Self—impenetrable, ancient, and reflective. The waking moment occurred right before touching the keys because the psyche is prompting the waking ego to do the real work in daytime reality. The dream was not a test you failed; it was an invitation delivered.`,
        schoolOfThought: 'Depth Psychology',
        symbolsAddressed: ['tower', 'keys'],
        reflectionPrompt: 'Can you name the three fundamental values that currently govern your life choices?',
        upvotes: 19,
        upvotedBy: ['user-sora', 'user-elena'],
        isDreamerCrowned: false,
        pointsAwarded: 205,
        createdAt: '2026-09-27T17:45:00Z'
      }
    ]
  },
  {
    id: 'dream-3',
    title: 'Flight over the Shattered Porcelain City',
    story: `I was hovering 500 feet above a city made entirely of white glazed porcelain and bone china. The streets were intricate tea-saucer circles and the skyscrapers were delicate fluted teapots and fragile vases.

I realized I was flying simply by exhaling slowly. If I inhaled, I lost altitude; if I held my breath, I hovered suspended. But whenever my shadow touched the porcelain roofs below, hairline fractures spread across the glaze, threatening to shatter whole neighborhoods into ceramic dust. I tried to fly higher toward the cloudbank so my shadow wouldn't destroy anything, but the wind grew icy.`,
    authorId: 'user-elena',
    authorName: 'Elena Rostova',
    authorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=150&q=80',
    authorTitle: 'Mythic Folklorist',
    mood: 'Anxious',
    lucidityLevel: 3,
    sleepStage: 'False Awakening',
    recurringSymbols: ['flying', 'falling', 'city'],
    views: 198,
    createdAt: '2026-09-26T21:10:00Z',
    crownedInterpretationId: null,
    interpretations: [
      {
        id: 'interp-5',
        dreamId: 'dream-3',
        authorId: 'user-sora',
        authorName: 'Sora Lin',
        authorTitle: 'Oneiric Artist',
        authorAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80',
        content: `The porcelain city is an exquisite metaphor for hyper-vigilance and fragile relationships. You fear that your mere presence—even just your shadow, your darker feelings or unspoken thoughts—will shatter the delicate order you or someone else built.

The breath control mechanism ties directly to somatic anxiety: shallow breathing keeps you safe, while exhaling (letting go) gives you lift. The unconscious is showing you how exhausting it is to avoid leaving any mark on the world out of fear of breaking fragile people.`,
        schoolOfThought: 'Subconscious Processing',
        symbolsAddressed: ['flying', 'city'],
        reflectionPrompt: 'Who in your circle are you treating like delicate porcelain at the expense of your own grounded freedom?',
        upvotes: 14,
        upvotedBy: ['user-kaelen', 'user-rowan'],
        isDreamerCrowned: false,
        pointsAwarded: 155,
        createdAt: '2026-09-26T23:05:00Z'
      }
    ]
  },
  {
    id: 'dream-4',
    title: 'The Library in the Hollowed Redwood',
    story: `Inside a colossal cedar tree whose canopy stretched into twilight stars, there was an endless spiral library. The shelves were not made of milled timber, but living boughs, and every book had tree bark covers with sap sealing the edges.

An archivist wearing a fox mask told me: 'You can read any volume, but each chapter you open removes one memory from your childhood.' I held a volume labeled 'The Architecture of Tomorrow' and could smell pine resin and ozone.`,
    authorId: 'user-kaelen',
    authorName: 'Kaelen Vane',
    authorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80',
    authorTitle: 'Archetypal Symbolist',
    mood: 'Ethereal',
    lucidityLevel: 4,
    sleepStage: 'Deep REM',
    recurringSymbols: ['forest', 'books', 'mask'],
    views: 245,
    createdAt: '2026-09-25T11:00:00Z',
    crownedInterpretationId: null,
    interpretations: []
  }
];

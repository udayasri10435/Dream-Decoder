import { DreamSymbolItem } from '../types.ts';

export const DREAM_SYMBOLS: DreamSymbolItem[] = [
  {
    id: 'ocean-deep-water',
    name: 'Deep Ocean & Waves',
    category: 'Nature & Elements',
    archetype: 'The Primordial Unconscious',
    meaning: 'Vast depths of emotion, repressed memories, and the unknown territory of the psyche. Gentle tides suggest emotional harmony, while violent undertows signal overwhelming unconscious currents.',
    jungianNote: 'Carl Jung viewed water as the quintessential symbol of the unconscious mind. Descending into the ocean represents ego confronting the shadow.',
    keywords: ['water', 'ocean', 'sea', 'waves', 'drowning', 'submerged']
  },
  {
    id: 'flight-levitation',
    name: 'Flight & Levitation',
    category: 'Motions & States',
    archetype: 'Transcendence / The Icarus Complex',
    meaning: 'Desire to rise above mundane earthly conflicts, sudden liberation, or cognitive detachment. Inability to maintain altitude reflects fear of losing grounding or hubris.',
    jungianNote: 'Represents the psyche striving toward individuation, yet carries the warning of spiritual inflation if ungrounded.',
    keywords: ['flying', 'levitation', 'floating', 'wings', 'soaring', 'sky']
  },
  {
    id: 'falling-abyss',
    name: 'Falling into the Void',
    category: 'Motions & States',
    archetype: 'Surrender of Ego Control',
    meaning: 'Acute anxiety regarding loss of grip over waking circumstances, sudden paradigm shifts, or the physiological hypnic jerk transition.',
    jungianNote: 'Symbolizes the collapse of conscious pretensions and involuntary descent into raw archetypal layers.',
    keywords: ['falling', 'abyss', 'cliff', 'gravity', 'plummeting']
  },
  {
    id: 'labyrinth-corridors',
    name: 'Endless Labyrinth & Hallways',
    category: 'Structures & Spaces',
    archetype: 'The Quest for Self / Intricate Mind',
    meaning: 'Searching for a hidden core identity, navigating convoluted dilemmas, feeling trapped in looping behavioral loops.',
    jungianNote: 'The maze is a sacred mandala in motion; reaching the center represents discovering the True Self after confronting internal beasts.',
    keywords: ['labyrinth', 'maze', 'hallway', 'corridor', 'doors', 'locks']
  },
  {
    id: 'tower-lighthouse',
    name: 'Lighthouse & Ancient Tower',
    category: 'Structures & Spaces',
    archetype: 'Consciousness & Beacon of Vigilance',
    meaning: 'Guiding illumination through dark existential passages, intellectual isolation, or the need to observe from a higher vantage point.',
    jungianNote: 'The tower embodies both solitary introspection and warning against emotional coldness.',
    keywords: ['lighthouse', 'tower', 'beacon', 'castle', 'spiral staircase']
  },
  {
    id: 'clocks-stopped-time',
    name: 'Clocks Without Hands / Melting Time',
    category: 'Objects & Relics',
    archetype: 'Kronos / Mortality & Timelessness',
    meaning: 'Existential awareness of slipping opportunities, panic about deadlines, or stepping into non-linear, sacred dreamtime.',
    jungianNote: 'Indicates the unconscious transcending linear causality (synchronicity realm).',
    keywords: ['clock', 'watch', 'hourglass', 'time', 'ticking', 'late']
  },
  {
    id: 'mirrors-reflections',
    name: 'Strange Mirrors & Distorted Doubles',
    category: 'Objects & Relics',
    archetype: 'The Persona & The Shadow',
    meaning: 'Questioning self-image, confrontation with hidden impulses, dissonance between how society perceives you and your inner reality.',
    jungianNote: 'Looking into a mirror in a dream is direct communion with the Shadow or Anima/Animus archetype.',
    keywords: ['mirror', 'reflection', 'glass', 'double', 'twin', 'face']
  },
  {
    id: 'black-panther-serpent',
    name: 'Shadow Serpent & Feline Beast',
    category: 'Creatures & Beasts',
    archetype: 'Instinctual Wisdom & Kundalini Energy',
    meaning: 'Raw primal intuition, creative vitality suppressed by overly rational conditioning, transformation through shedding skin.',
    jungianNote: 'Serpents guard the threshold of the deep self; fear of the beast indicates alienation from instinctive nature.',
    keywords: ['snake', 'serpent', 'panther', 'wolf', 'lion', 'beast']
  },
  {
    id: 'teeth-crumbling',
    name: 'Crumbling or Falling Teeth',
    category: 'Motions & States',
    archetype: 'Vulnerability & Loss of Power',
    meaning: 'Anxiety about aging, loss of persuasive bite in waking life, fear of social exposure, or transition through major life thresholds.',
    jungianNote: 'Points to structural reorganization of identity where old defense mechanisms crumble.',
    keywords: ['teeth', 'jaw', 'mouth', 'biting', 'crumbling']
  },
  {
    id: 'train-empty-station',
    name: 'Subterranean Trains & Midnight Stations',
    category: 'Structures & Spaces',
    archetype: 'Collective Destiny & Inevitable Paths',
    meaning: 'Feeling swept along a fixed life trajectory, anxiety about missing a critical crossroads, moving between unconscious stations.',
    jungianNote: 'Trains represent collective unconscious momentum—are you the conductor or a powerless passenger?',
    keywords: ['train', 'station', 'tracks', 'platform', 'ticket', 'locomotive']
  },
  {
    id: 'forest-whispering-trees',
    name: 'Ancient Whispering Forest',
    category: 'Nature & Elements',
    archetype: 'The Great Mother & Primeval Mystery',
    meaning: 'Entering a fertile but untamed realm of memory, intuition, and ancestral wisdom. Losing one’s path invites inner stillness.',
    jungianNote: 'The forest represents the realm of instincts where the hero must wander before finding clarity.',
    keywords: ['forest', 'woods', 'trees', 'roots', 'leaves', 'dark forest']
  },
  {
    id: 'locked-box-key',
    name: 'Ornate Chest & Golden Key',
    category: 'Objects & Relics',
    archetype: 'The Hidden Treasure / Repressed Gift',
    meaning: 'Latent creative genius or guarded grief awaiting conscious integration. Searching for the key reveals readiness to unlock forbidden truths.',
    jungianNote: 'Symbolizes the philosophical gold of alchemy—turning suffering into integrated wisdom.',
    keywords: ['key', 'chest', 'box', 'lock', 'vault', 'treasure']
  }
];

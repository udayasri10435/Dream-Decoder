import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { DreamFeed } from './components/DreamFeed.tsx';
import { DreamDetail } from './components/DreamDetail.tsx';
import { LeaderboardView } from './components/LeaderboardView.tsx';
import { SymbolLexiconView } from './components/SymbolLexiconView.tsx';
import { AboutRulesView } from './components/AboutRulesView.tsx';
import { SubmitDreamModal } from './components/SubmitDreamModal.tsx';
import { Dream, UserProfile, DreamMood, SleepStage, SchoolOfThought } from './types.ts';
import { INITIAL_DREAMS, INITIAL_USERS } from './data/mockDreams.ts';
import { Sparkles, Trophy, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'feed' | 'lexicon' | 'leaderboard' | 'about'>('feed');
  const [dreams, setDreams] = useState<Dream[]>(INITIAL_DREAMS);
  const [allUsers, setAllUsers] = useState<UserProfile[]>(INITIAL_USERS);
  const [currentUser, setCurrentUser] = useState<UserProfile>(INITIAL_USERS[0]);
  const [selectedDream, setSelectedDream] = useState<Dream | null>(null);
  const [activeSymbolFilter, setActiveSymbolFilter] = useState<string | null>(null);
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);
  const [isConsultingOracle, setIsConsultingOracle] = useState(false);
  
  // Real-time toast feedback for points & actions
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, 4500);
  };

  // Fetch initial data from server
  const fetchData = async () => {
    try {
      const [dreamsRes, usersRes] = await Promise.all([
        fetch('/api/dreams'),
        fetch('/api/users')
      ]);

      if (dreamsRes.ok) {
        const dreamsData = await dreamsRes.json();
        if (dreamsData.dreams) {
          setDreams(dreamsData.dreams);
          // If a dream is currently open, sync it
          setSelectedDream((prev) => 
            prev ? dreamsData.dreams.find((d: Dream) => d.id === prev.id) || prev : null
          );
        }
      }

      if (usersRes.ok) {
        const usersData = await usersRes.json();
        if (usersData.users) {
          setAllUsers(usersData.users);
          // Sync current user with server points
          setCurrentUser((prev) => 
            usersData.users.find((u: UserProfile) => u.id === prev.id) || prev
          );
        }
      }
    } catch (err) {
      console.warn('Backend API not responding, using client state:', err);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Handle switching active persona
  const handleSelectUser = (user: UserProfile) => {
    setCurrentUser(user);
    showToast(`Switched active persona to ${user.name} (${user.points} pts)`);
  };

  // Handle submitting new dream
  const handleSubmitDream = async (dreamData: {
    title: string;
    story: string;
    mood: DreamMood;
    lucidityLevel: number;
    sleepStage: SleepStage;
    recurringSymbols: string[];
  }) => {
    try {
      const res = await fetch('/api/dreams', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...dreamData,
          authorId: currentUser.id,
        })
      });

      if (res.ok) {
        const data = await res.json();
        setDreams((prev) => [data.dream, ...prev]);
        // Update user points +5
        setCurrentUser((prev) => ({
          ...prev,
          points: prev.points + 5,
          dreamsSubmitted: prev.dreamsSubmitted + 1
        }));
        showToast('🌟 Dream recorded! You earned +5 points.');
        setSelectedDream(data.dream);
      } else {
        // Fallback local creation
        const newLocalDream: Dream = {
          id: `dream-${Date.now()}`,
          ...dreamData,
          authorId: currentUser.id,
          authorName: currentUser.name,
          authorAvatar: currentUser.avatar,
          authorTitle: currentUser.title,
          interpretations: [],
          crownedInterpretationId: null,
          views: 1,
          createdAt: new Date().toISOString()
        };
        setDreams((prev) => [newLocalDream, ...prev]);
        setCurrentUser((prev) => ({
          ...prev,
          points: prev.points + 5,
          dreamsSubmitted: prev.dreamsSubmitted + 1
        }));
        showToast('🌟 Dream recorded! You earned +5 points.');
        setSelectedDream(newLocalDream);
      }
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  // Handle submitting interpretation
  const handleSubmitInterpretation = async (data: {
    content: string;
    schoolOfThought: SchoolOfThought;
    symbolsAddressed: string[];
    reflectionPrompt: string;
  }) => {
    if (!selectedDream) return;

    try {
      const res = await fetch(`/api/dreams/${selectedDream.id}/interpretations`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          authorId: currentUser.id,
        })
      });

      if (res.ok) {
        const result = await res.json();
        const updatedDream = {
          ...selectedDream,
          interpretations: [...selectedDream.interpretations, result.interpretation]
        };
        setSelectedDream(updatedDream);
        setDreams((prev) =>
          prev.map((d) => (d.id === updatedDream.id ? updatedDream : d))
        );
        setCurrentUser((prev) => ({
          ...prev,
          points: prev.points + 15,
          interpretationsCount: prev.interpretationsCount + 1
        }));
        showToast('📜 Decode submitted! You earned +15 points.');
      } else {
        // Local fallback
        const newInterp = {
          id: `interp-${Date.now()}`,
          dreamId: selectedDream.id,
          authorId: currentUser.id,
          authorName: currentUser.name,
          authorAvatar: currentUser.avatar,
          authorTitle: currentUser.title,
          content: data.content,
          schoolOfThought: data.schoolOfThought,
          symbolsAddressed: data.symbolsAddressed,
          reflectionPrompt: data.reflectionPrompt,
          upvotes: 0,
          upvotedBy: [],
          isDreamerCrowned: false,
          pointsAwarded: 15,
          createdAt: new Date().toISOString()
        };
        const updatedDream = {
          ...selectedDream,
          interpretations: [...selectedDream.interpretations, newInterp]
        };
        setSelectedDream(updatedDream);
        setDreams((prev) =>
          prev.map((d) => (d.id === updatedDream.id ? updatedDream : d))
        );
        setCurrentUser((prev) => ({
          ...prev,
          points: prev.points + 15,
          interpretationsCount: prev.interpretationsCount + 1
        }));
        showToast('📜 Decode submitted! You earned +15 points.');
      }
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  // Handle upvote / resonance
  const handleVoteInterpretation = async (interpId: string) => {
    try {
      const res = await fetch(`/api/interpretations/${interpId}/vote`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id })
      });

      if (res.ok) {
        const data = await res.json();
        showToast(data.message);
        
        // Update dreams state
        setDreams((prev) =>
          prev.map((d) => {
            const hasInterp = d.interpretations.some((i) => i.id === interpId);
            if (!hasInterp) return d;
            return {
              ...d,
              interpretations: d.interpretations.map((i) => {
                if (i.id !== interpId) return i;
                const voted = i.upvotedBy.includes(currentUser.id);
                return {
                  ...i,
                  upvotes: data.upvotes,
                  upvotedBy: voted
                    ? i.upvotedBy.filter((id) => id !== currentUser.id)
                    : [...i.upvotedBy, currentUser.id],
                  pointsAwarded: data.pointsAwarded
                };
              })
            };
          })
        );

        if (selectedDream) {
          setSelectedDream((prev) => {
            if (!prev) return null;
            return {
              ...prev,
              interpretations: prev.interpretations.map((i) => {
                if (i.id !== interpId) return i;
                const voted = i.upvotedBy.includes(currentUser.id);
                return {
                  ...i,
                  upvotes: data.upvotes,
                  upvotedBy: voted
                    ? i.upvotedBy.filter((id) => id !== currentUser.id)
                    : [...i.upvotedBy, currentUser.id],
                  pointsAwarded: data.pointsAwarded
                };
              })
            };
          });
        }
      }
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  // Handle crowning winning interpretation
  const handleCrownWinner = async (interpId: string) => {
    if (!selectedDream) return;

    try {
      const res = await fetch(`/api/dreams/${selectedDream.id}/crown-winner`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          interpretationId: interpId,
          userId: currentUser.id
        })
      });

      if (res.ok) {
        const data = await res.json();
        showToast(data.message);
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Handle consulting AI Oracle
  const handleConsultOracle = async () => {
    if (!selectedDream) return;

    try {
      setIsConsultingOracle(true);
      const res = await fetch(`/api/dreams/${selectedDream.id}/oracle-decode`, {
        method: 'POST'
      });

      if (res.ok) {
        const data = await res.json();
        if (data.oracleAnalysis) {
          const updated = {
            ...selectedDream,
            oracleAnalysis: data.oracleAnalysis
          };
          setSelectedDream(updated);
          setDreams((prev) =>
            prev.map((d) => (d.id === updated.id ? updated : d))
          );
          showToast('🔮 The Oracle has revealed archetypal patterns.');
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsConsultingOracle(false);
    }
  };

  // Symbol click from lexicon
  const handleSelectSymbolForFeed = (sym: string) => {
    setActiveSymbolFilter(sym);
    setSelectedDream(null);
    setActiveTab('feed');
  };

  return (
    <div className="min-h-screen dream-backdrop flex flex-col justify-between">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#121428] border border-indigo-500/40 text-slate-100 text-xs px-4 py-3 rounded-xl shadow-2xl shadow-black/80 flex items-center gap-3 animate-in fade-in slide-in-from-bottom-2">
          <Sparkles className="w-4 h-4 text-indigo-400 shrink-0" />
          <span>{toastMessage}</span>
          <button 
            onClick={() => setToastMessage(null)}
            className="text-slate-400 hover:text-white text-xs ml-1"
          >
            ✕
          </button>
        </div>
      )}

      <div>
        {/* Navigation */}
        <Navbar
          activeTab={activeTab}
          setActiveTab={(tab) => {
            setActiveTab(tab);
            setSelectedDream(null);
          }}
          currentUser={currentUser}
          allUsers={allUsers}
          onSelectUser={handleSelectUser}
          onOpenSubmitDream={() => setIsSubmitModalOpen(true)}
        />

        {/* Main Content Area */}
        <main className="pb-16">
          {selectedDream ? (
            <DreamDetail
              dream={selectedDream}
              currentUser={currentUser}
              onBack={() => setSelectedDream(null)}
              onVoteInterpretation={handleVoteInterpretation}
              onCrownWinner={handleCrownWinner}
              onSubmitInterpretation={handleSubmitInterpretation}
              onConsultOracle={handleConsultOracle}
              isConsultingOracle={isConsultingOracle}
            />
          ) : (
            <>
              {activeTab === 'feed' && (
                <DreamFeed
                  dreams={dreams}
                  onSelectDream={(d) => setSelectedDream(d)}
                  activeSymbolFilter={activeSymbolFilter}
                  onClearSymbolFilter={() => setActiveSymbolFilter(null)}
                  onFilterSymbol={(sym) => setActiveSymbolFilter(sym)}
                  onOpenSubmitDream={() => setIsSubmitModalOpen(true)}
                />
              )}

              {activeTab === 'leaderboard' && (
                <LeaderboardView
                  users={allUsers}
                  currentUser={currentUser}
                  onSelectUser={handleSelectUser}
                  onOpenSubmitDream={() => setIsSubmitModalOpen(true)}
                />
              )}

              {activeTab === 'lexicon' && (
                <SymbolLexiconView
                  onSelectSymbolForFeed={handleSelectSymbolForFeed}
                />
              )}

              {activeTab === 'about' && (
                <AboutRulesView />
              )}
            </>
          )}
        </main>
      </div>

      {/* Submit Dream Modal */}
      <SubmitDreamModal
        isOpen={isSubmitModalOpen}
        onClose={() => setIsSubmitModalOpen(false)}
        currentUser={currentUser}
        onSubmitDream={handleSubmitDream}
      />

      {/* Footer */}
      <footer className="border-t border-white/[0.06] bg-[#07080f] py-8 text-center text-xs text-slate-400">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-display font-semibold text-slate-300">DREAM DECODER</span>
            <span aria-hidden="true" className="text-slate-700">·</span>
            <span>A nocturnal community for collective subconscious mapping</span>
          </div>
          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span>Points awarded for resonance and truth</span>
            <span aria-hidden="true" className="text-slate-700">·</span>
            <button 
              onClick={() => {
                setActiveTab('about');
                setSelectedDream(null);
              }}
              className="hover:text-indigo-300 underline"
            >
              Point Rules
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}

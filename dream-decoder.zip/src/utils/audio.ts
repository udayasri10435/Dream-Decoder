// Gentle nocturnal ambient sound generator using Web Audio API
class DreamAudioPlayer {
  private ctx: AudioContext | null = null;
  private oscillator1: OscillatorNode | null = null;
  private oscillator2: OscillatorNode | null = null;
  private gainNode: GainNode | null = null;
  private isPlaying: boolean = false;

  public toggle(): boolean {
    if (this.isPlaying) {
      this.stop();
      return false;
    } else {
      this.start();
      return true;
    }
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }

  public start() {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!this.ctx) {
        this.ctx = new AudioCtx();
      }
      if (this.ctx.state === 'suspended') {
        this.ctx.resume();
      }

      this.gainNode = this.ctx.createGain();
      this.gainNode.gain.setValueAtTime(0.001, this.ctx.currentTime);
      this.gainNode.gain.exponentialRampToValueAtTime(0.04, this.ctx.currentTime + 3);

      // Low soothing binaural dream frequency (theta wave ~ 108Hz and 114Hz)
      this.oscillator1 = this.ctx.createOscillator();
      this.oscillator1.type = 'sine';
      this.oscillator1.frequency.setValueAtTime(108, this.ctx.currentTime);

      this.oscillator2 = this.ctx.createOscillator();
      this.oscillator2.type = 'sine';
      this.oscillator2.frequency.setValueAtTime(114, this.ctx.currentTime);

      // Filter for warm, submerged night feel
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(320, this.ctx.currentTime);

      this.oscillator1.connect(filter);
      this.oscillator2.connect(filter);
      filter.connect(this.gainNode);
      this.gainNode.connect(this.ctx.destination);

      this.oscillator1.start();
      this.oscillator2.start();
      this.isPlaying = true;
    } catch (e) {
      console.warn('AudioContext not allowed or not supported:', e);
      this.isPlaying = false;
    }
  }

  public stop() {
    try {
      if (this.gainNode && this.ctx) {
        this.gainNode.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 1);
        setTimeout(() => {
          this.oscillator1?.stop();
          this.oscillator2?.stop();
          this.oscillator1?.disconnect();
          this.oscillator2?.disconnect();
          this.isPlaying = false;
        }, 1000);
      } else {
        this.isPlaying = false;
      }
    } catch (e) {
      this.isPlaying = false;
    }
  }
}

export const dreamAudio = new DreamAudioPlayer();

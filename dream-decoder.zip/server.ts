import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { INITIAL_DREAMS, INITIAL_USERS } from './src/data/mockDreams.ts';
import { DREAM_SYMBOLS } from './src/data/symbols.ts';
import { Dream, Interpretation, UserProfile, SchoolOfThought } from './src/types.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// In-memory persistent state during server runtime
let users: UserProfile[] = JSON.parse(JSON.stringify(INITIAL_USERS));
let dreams: Dream[] = JSON.parse(JSON.stringify(INITIAL_DREAMS));

// Helper: Calculate user rank title & level based on points
function recalculateUserRank(user: UserProfile) {
  if (user.points >= 1000) {
    user.rankName = 'Grand Oracle';
    user.level = 5;
  } else if (user.points >= 500) {
    user.rankName = 'Depth Psychologist';
    user.level = 4;
  } else if (user.points >= 200) {
    user.rankName = 'Archetype Weaver';
    user.level = 3;
  } else if (user.points >= 50) {
    user.rankName = 'Lucid Wanderer';
    user.level = 2;
  } else {
    user.rankName = 'Dream Novice';
    user.level = 1;
  }

  // Check badges
  if (user.winsCount >= 1 && !user.badges.some(b => b.id === 'b-first-win')) {
    user.badges.push({
      id: 'b-first-win',
      name: 'Resonance Winner',
      description: 'Crowned as the most resonant dream decoder',
      icon: 'crown',
      tier: 'gold'
    });
  }
  if (user.interpretationsCount >= 5 && !user.badges.some(b => b.id === 'b-prolific')) {
    user.badges.push({
      id: 'b-prolific',
      name: 'Dedicated Analyst',
      description: 'Authored 5 or more in-depth interpretations',
      icon: 'book-open',
      tier: 'silver'
    });
  }
}

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// --- API ENDPOINTS ---

// GET /api/users - Get all profiles
app.get('/api/users', (req: Request, res: Response) => {
  users.forEach(recalculateUserRank);
  res.json({ users });
});

// GET /api/dreams - List all dreams
app.get('/api/dreams', (req: Request, res: Response) => {
  // Sort by newest
  const sorted = [...dreams].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  res.json({ dreams: sorted });
});

// GET /api/dreams/:id - Get specific dream
app.get('/api/dreams/:id', (req: Request, res: Response) => {
  const dream = dreams.find(d => d.id === req.params.id);
  if (!dream) {
    return res.status(404).json({ error: 'Dream not found' });
  }
  dream.views += 1;
  res.json({ dream });
});

// POST /api/dreams - Submit new dream
app.post('/api/dreams', (req: Request, res: Response) => {
  const { title, story, authorId, mood, lucidityLevel, sleepStage, recurringSymbols } = req.body;
  if (!title || !story || !authorId) {
    return res.status(400).json({ error: 'Title, story, and author are required' });
  }

  const author = users.find(u => u.id === authorId);
  const newDream: Dream = {
    id: `dream-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    title,
    story,
    authorId,
    authorName: author ? author.name : 'Anonymous Dreamer',
    authorAvatar: author ? author.avatar : 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
    authorTitle: author ? author.title : 'Oneironaut',
    mood: mood || 'Surreal',
    lucidityLevel: Number(lucidityLevel) || 3,
    sleepStage: sleepStage || 'Deep REM',
    recurringSymbols: Array.isArray(recurringSymbols) ? recurringSymbols : [],
    interpretations: [],
    crownedInterpretationId: null,
    views: 1,
    createdAt: new Date().toISOString()
  };

  dreams.unshift(newDream);

  // Award dreamer 5 points for logging their dream
  if (author) {
    author.points += 5;
    author.dreamsSubmitted += 1;
    recalculateUserRank(author);
  }

  res.status(201).json({ dream: newDream, message: 'Dream logged successfully! +5 points awarded.' });
});

// POST /api/dreams/:id/interpretations - Submit community interpretation
app.post('/api/dreams/:id/interpretations', (req: Request, res: Response) => {
  const dream = dreams.find(d => d.id === req.params.id);
  if (!dream) {
    return res.status(404).json({ error: 'Dream not found' });
  }

  const { authorId, content, schoolOfThought, symbolsAddressed, reflectionPrompt } = req.body;
  if (!content || !authorId) {
    return res.status(400).json({ error: 'Interpretation content and author are required' });
  }

  const author = users.find(u => u.id === authorId);
  const newInterpretation: Interpretation = {
    id: `interp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    dreamId: dream.id,
    authorId,
    authorName: author ? author.name : 'Fellow Dreamer',
    authorAvatar: author ? author.avatar : 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
    authorTitle: author ? author.title : 'Dream Analyst',
    content,
    schoolOfThought: (schoolOfThought as SchoolOfThought) || 'Jungian Archetype',
    symbolsAddressed: Array.isArray(symbolsAddressed) ? symbolsAddressed : [],
    reflectionPrompt: reflectionPrompt || '',
    upvotes: 0,
    upvotedBy: [],
    isDreamerCrowned: false,
    pointsAwarded: 15, // Base points for sharing an interpretation
    createdAt: new Date().toISOString()
  };

  dream.interpretations.push(newInterpretation);

  // Award author 15 base points
  if (author) {
    author.points += 15;
    author.interpretationsCount += 1;
    recalculateUserRank(author);
  }

  res.status(201).json({
    interpretation: newInterpretation,
    message: 'Interpretation submitted! You earned +15 decoder points.'
  });
});

// POST /api/interpretations/:id/vote - Upvote / Resonate with an interpretation
app.post('/api/interpretations/:id/vote', (req: Request, res: Response) => {
  const { userId } = req.body;
  if (!userId) {
    return res.status(400).json({ error: 'User ID is required to vote' });
  }

  let foundInterp: Interpretation | null = null;
  let parentDream: Dream | null = null;

  for (const d of dreams) {
    const interp = d.interpretations.find(i => i.id === req.params.id);
    if (interp) {
      foundInterp = interp;
      parentDream = d;
      break;
    }
  }

  if (!foundInterp || !parentDream) {
    return res.status(404).json({ error: 'Interpretation not found' });
  }

  const author = users.find(u => u.id === foundInterp!.authorId);
  const alreadyVotedIndex = foundInterp.upvotedBy.indexOf(userId);

  let voted = false;
  if (alreadyVotedIndex >= 0) {
    // Remove vote
    foundInterp.upvotedBy.splice(alreadyVotedIndex, 1);
    foundInterp.upvotes = Math.max(0, foundInterp.upvotes - 1);
    foundInterp.pointsAwarded = Math.max(15, foundInterp.pointsAwarded - 10);
    if (author) {
      author.points = Math.max(0, author.points - 10);
      recalculateUserRank(author);
    }
    voted = false;
  } else {
    // Add vote: +10 points to author
    foundInterp.upvotedBy.push(userId);
    foundInterp.upvotes += 1;
    foundInterp.pointsAwarded += 10;
    if (author) {
      author.points += 10;
      recalculateUserRank(author);
    }
    voted = true;
  }

  res.json({
    upvotes: foundInterp.upvotes,
    voted,
    pointsAwarded: foundInterp.pointsAwarded,
    authorPoints: author?.points ?? 0,
    message: voted ? 'Resonated! The interpreter earned +10 points.' : 'Vote removed.'
  });
});

// POST /api/dreams/:id/crown-winner - Dreamer crowns winning interpretation
app.post('/api/dreams/:id/crown-winner', (req: Request, res: Response) => {
  const { interpretationId, userId } = req.body;
  const dream = dreams.find(d => d.id === req.params.id);
  if (!dream) {
    return res.status(404).json({ error: 'Dream not found' });
  }

  // Only dream author can crown
  if (dream.authorId !== userId) {
    return res.status(403).json({ error: 'Only the original dreamer can crown the winning interpretation' });
  }

  const interp = dream.interpretations.find(i => i.id === interpretationId);
  if (!interp) {
    return res.status(404).json({ error: 'Interpretation not found' });
  }

  // If already crowned this one, uncrown
  if (dream.crownedInterpretationId === interp.id) {
    dream.crownedInterpretationId = null;
    interp.isDreamerCrowned = false;
    interp.pointsAwarded -= 50;
    const author = users.find(u => u.id === interp.authorId);
    if (author) {
      author.points = Math.max(0, author.points - 50);
      author.winsCount = Math.max(0, author.winsCount - 1);
      recalculateUserRank(author);
    }
    return res.json({
      crowned: false,
      message: 'Crown removed from interpretation.'
    });
  }

  // If another interpretation was previously crowned, deduct its bonus
  if (dream.crownedInterpretationId) {
    const prev = dream.interpretations.find(i => i.id === dream.crownedInterpretationId);
    if (prev) {
      prev.isDreamerCrowned = false;
      prev.pointsAwarded -= 50;
      const prevAuthor = users.find(u => u.id === prev.authorId);
      if (prevAuthor) {
        prevAuthor.points = Math.max(0, prevAuthor.points - 50);
        prevAuthor.winsCount = Math.max(0, prevAuthor.winsCount - 1);
        recalculateUserRank(prevAuthor);
      }
    }
  }

  // Crown new winner
  dream.crownedInterpretationId = interp.id;
  interp.isDreamerCrowned = true;
  interp.pointsAwarded += 50;
  const author = users.find(u => u.id === interp.authorId);
  if (author) {
    author.points += 50;
    author.winsCount += 1;
    recalculateUserRank(author);
  }

  res.json({
    crowned: true,
    crownedInterpretationId: interp.id,
    authorPoints: author?.points ?? 0,
    message: `👑 Epiphany Crowned! ${interp.authorName} won +50 bonus points!`
  });
});

// POST /api/dreams/:id/oracle-decode - AI Jungian Archetype Oracle
app.post('/api/dreams/:id/oracle-decode', async (req: Request, res: Response) => {
  const dream = dreams.find(d => d.id === req.params.id);
  if (!dream) {
    return res.status(404).json({ error: 'Dream not found' });
  }

  // If already analyzed, return cached analysis
  if (dream.oracleAnalysis) {
    return res.json({ oracleAnalysis: dream.oracleAnalysis });
  }

  // If Gemini API is available, generate fresh archetypal decode
  if (ai) {
    try {
      const prompt = `You are a world-class depth psychologist and scholar of Carl Jung, Joseph Campbell, and comparative mythology.
Analyze this user's dream with profound psychological nuance, poetic resonance, and respectful curiosity.

Dream Title: "${dream.title}"
Dreamer's Log:
"${dream.story}"
Mood: ${dream.mood}
Lucidity: ${dream.lucidityLevel}/5
Sleep Stage: ${dream.sleepStage}

Return a valid JSON object matching this exact structure:
{
  "summary": "A 1-2 sentence core archetypal essence of this dream.",
  "archetypes": [
    {
      "name": "Name of archetype (e.g. The Threshold Guardian, The Anima in Shadow, The Shattered Persona)",
      "description": "How it manifests specifically in this narrative",
      "meaning": "What psychological integration or inquiry it asks of the dreamer"
    },
    {
      "name": "Second Archetype name",
      "description": "Specific manifestation",
      "meaning": "Psychological inquiry"
    }
  ],
  "shadowSelfReflection": "A thoughtful exploration of what disowned emotions, desires, or anxieties may be speaking through this imagery.",
  "unconsciousTension": "The core dialectic or conflict between conscious waking ego and unconscious drive.",
  "guidedInquiry": "A deep, contemplative question for the dreamer to journal upon."
}

Do not include markdown code block ticks (\`\`\`json) in the response if possible, or provide raw JSON only.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json'
        }
      });

      const responseText = response.text || '';
      try {
        const parsed = JSON.parse(responseText);
        dream.oracleAnalysis = parsed;
        return res.json({ oracleAnalysis: dream.oracleAnalysis });
      } catch (parseErr) {
        console.error('Failed to parse Gemini JSON output:', responseText);
      }
    } catch (err: any) {
      console.warn('Gemini API call warning, falling back to evocative template:', err?.message || err);
    }
  }

  // Evocative fallback based on dream motifs & mood
  const fallbackAnalysis = {
    summary: `A profound threshold narrative navigating the tension of ${dream.mood.toLowerCase()} states and unconscious individuation.`,
    archetypes: [
      {
        name: 'The Nocturnal Threshold Guardian',
        description: `Represented by the central motifs and boundaries in "${dream.title}".`,
        meaning: 'Demands that the waking ego surrender habitual defenses before crossing into emotional transformation.'
      },
      {
        name: 'The Living Metaphor of the Persona',
        description: 'The narrative elements that mirror external expectations versus internal truths.',
        meaning: 'Points toward areas where waking identity feels strained, fragmented, or ripe for authentic rebirth.'
      }
    ],
    shadowSelfReflection: `This dream reveals subconscious impulses that the conscious mind keeps at bay during daylight hours. The atmosphere of ${dream.mood} suggests unintegrated emotional energy seeking expression.`,
    unconsciousTension: 'The struggle between the desire for conscious control and the inevitability of instinctual surrender.',
    guidedInquiry: `When you wake from "${dream.title}", what is the first emotion that lingers before thoughts take over?`
  };

  dream.oracleAnalysis = fallbackAnalysis;
  res.json({ oracleAnalysis: dream.oracleAnalysis });
});

// GET /api/leaderboard - Community Leaderboard & Ranks
app.get('/api/leaderboard', (req: Request, res: Response) => {
  users.forEach(recalculateUserRank);
  // Sort by points descending
  const sorted = [...users].sort((a, b) => b.points - a.points);
  res.json({ leaderboard: sorted });
});

// GET /api/symbols - Symbols Lexicon
app.get('/api/symbols', (req: Request, res: Response) => {
  res.json({ symbols: DREAM_SYMBOLS });
});

// In production, serve Vite build files. In dev, Vite middleware is attached
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, 'dist')));
  app.get('*', (req: Request, res: Response) => {
    res.sendFile(path.join(__dirname, 'dist', 'index.html'));
  });
} else {
  // Vite Dev Server middleware
  import('vite').then(async ({ createServer }) => {
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  });
}

app.listen(PORT, () => {
  console.log(`Dream Decoder server running on port ${PORT}`);
});
